const on = document.getElementById("on");
const st = document.getElementById("st");

chrome.storage.local.get("enabled").then(({ enabled = true }) => {
  on.checked = enabled;
});
on.addEventListener("change", () => chrome.storage.local.set({ enabled: on.checked }));

fetch("http://127.0.0.1:6892/ping", { cache: "no-store" })
  .then((r) => (r.ok ? r.json() : Promise.reject()))
  .then(() => {
    st.textContent = "✔ Turit অ্যাপের সাথে যুক্ত / Connected";
    st.className = "st ok";
  })
  .catch(() => {
    st.textContent = "✖ Turit অ্যাপ চালু নেই / App not running";
    st.className = "st bad";
  });
