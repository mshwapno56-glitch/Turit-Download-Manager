use crate::model::ReqHeaders;
use percent_encoding::percent_decode_str;
use reqwest::header::{CONTENT_DISPOSITION, CONTENT_RANGE, RANGE};
use reqwest::{Client, RequestBuilder, Url};

pub struct Probe {
    pub total: Option<u64>,
    pub resumable: bool,
    pub filename: String,
}

pub fn apply_headers(mut req: RequestBuilder, h: &ReqHeaders) -> RequestBuilder {
    if let Some(r) = h.referer.as_deref().filter(|s| !s.is_empty()) {
        req = req.header(reqwest::header::REFERER, r);
    }
    if let Some(c) = h.cookie.as_deref().filter(|s| !s.is_empty()) {
        req = req.header(reqwest::header::COOKIE, c);
    }
    let ua = h
        .user_agent
        .as_deref()
        .filter(|s| !s.is_empty())
        .unwrap_or("Mozilla/5.0 (Windows NT 10.0; Win64; x64) Turit/0.1");
    req.header(reqwest::header::USER_AGENT, ua)
}

/// Ask the server for byte 0 only: tells us size, range support and file name.
pub async fn probe(client: &Client, url: &str, h: &ReqHeaders) -> Result<Probe, String> {
    let resp = apply_headers(client.get(url), h)
        .header(RANGE, "bytes=0-0")
        .send()
        .await
        .map_err(|e| e.to_string())?;
    let st = resp.status();
    let final_url = resp.url().clone();
    let cd = resp
        .headers()
        .get(CONTENT_DISPOSITION)
        .and_then(|v| v.to_str().ok())
        .map(|s| s.to_string());

    let (total, resumable) = if st.as_u16() == 206 {
        let total = resp
            .headers()
            .get(CONTENT_RANGE)
            .and_then(|v| v.to_str().ok())
            .and_then(|s| s.rsplit('/').next())
            .and_then(|s| s.trim().parse::<u64>().ok());
        (total, total.is_some())
    } else if st.as_u16() == 416 {
        (Some(0), false) // empty file
    } else if st.is_success() {
        (resp.content_length(), false)
    } else {
        return Err(format!("HTTP {}", st.as_u16()));
    };
    drop(resp);

    let name = cd
        .as_deref()
        .and_then(name_from_disposition)
        .unwrap_or_else(|| name_from_url(&final_url));
    Ok(Probe { total, resumable, filename: sanitize(&name) })
}

pub fn name_from_url(u: &Url) -> String {
    let last = u
        .path_segments()
        .and_then(|s| s.filter(|x| !x.is_empty()).last())
        .map(|s| percent_decode_str(s).decode_utf8_lossy().to_string())
        .unwrap_or_default();
    if last.is_empty() {
        sanitize(u.host_str().unwrap_or("download"))
    } else {
        sanitize(&last)
    }
}

fn name_from_disposition(cd: &str) -> Option<String> {
    let lower = cd.to_ascii_lowercase();
    if let Some(p) = lower.find("filename*=") {
        let v = cd[p + 10..].split(';').next()?.trim();
        // RFC 5987: charset'lang'percent-encoded
        let enc = v.splitn(3, '\'').nth(2).unwrap_or(v);
        let s = percent_decode_str(enc.trim_matches('"')).decode_utf8_lossy().to_string();
        if !s.is_empty() {
            return Some(s);
        }
    }
    if let Some(p) = lower.find("filename=") {
        let v = cd[p + 9..].split(';').next()?.trim().trim_matches('"').to_string();
        if !v.is_empty() {
            return Some(v);
        }
    }
    None
}

/// Make a string safe as a Windows/Linux file name.
pub fn sanitize(name: &str) -> String {
    let mut s: String = name
        .chars()
        .map(|c| if c.is_control() || "<>:\"/\\|?*".contains(c) { '_' } else { c })
        .collect();
    s = s.trim().trim_end_matches(['.', ' ']).to_string();
    if s.chars().count() > 150 {
        let ext: String = s.rsplit_once('.').map(|(_, e)| e.chars().take(10).collect()).unwrap_or_default();
        let base: String = s.chars().take(140).collect();
        s = if ext.is_empty() { base } else { format!("{base}.{ext}") };
    }
    let stem = s.split('.').next().unwrap_or("").to_ascii_uppercase();
    const RESERVED: [&str; 22] = [
        "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
        "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9",
    ];
    if RESERVED.contains(&stem.as_str()) {
        s = format!("_{s}");
    }
    if s.is_empty() {
        "download".into()
    } else {
        s
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sanitize_works() {
        assert_eq!(sanitize("a/b:c?.zip"), "a_b_c_.zip");
        assert_eq!(sanitize("CON.txt"), "_CON.txt");
        assert_eq!(sanitize("  "), "download");
        assert_eq!(sanitize("file. . "), "file");
    }

    #[test]
    fn disposition_parsing() {
        assert_eq!(name_from_disposition("attachment; filename=\"a b.zip\"").unwrap(), "a b.zip");
        assert_eq!(name_from_disposition("attachment; filename*=UTF-8''%E0%A6%AC.pdf").unwrap(), "ব.pdf");
        assert!(name_from_disposition("inline").is_none());
    }

    #[test]
    fn url_name() {
        let u = Url::parse("https://x.com/dl/my%20file.iso?token=1").unwrap();
        assert_eq!(name_from_url(&u), "my file.iso");
    }
}
