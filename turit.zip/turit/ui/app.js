"use strict";

// ---------------------------------------------------------------- i18n
const I18N = {
  bn: {
    tagline: "তড়িৎ গতির ডাউনলোডার",
    add: "যোগ করুন", resumeAll: "সব চালু করুন", pauseAll: "সব থামান", settings: "সেটিংস",
    tabAll: "সব", tabActive: "চলছে", tabDone: "সম্পন্ন",
    emptyTitle: "এখনো কোনো ডাউনলোড নেই", emptyHint: "“যোগ করুন” চাপুন বা লিংক পেস্ট করুন",
    addTitle: "নতুন ডাউনলোড", links: "লিংক (প্রতি লাইনে একটি)", saveTo: "কোথায় সেভ হবে", browse: "বাছাই",
    fileName: "ফাইলের নাম", optional: "(ঐচ্ছিক)", cancel: "বাতিল", download: "ডাউনলোড", save: "সেভ",
    defaultFolder: "ডিফল্ট ফোল্ডার", connections: "প্রতি ফাইলে সংযোগ", maxActive: "একসাথে ডাউনলোড",
    extNote: "ব্রাউজার এক্সটেনশন এই অ্যাপের সাথে 127.0.0.1:6892 পোর্টে যুক্ত হয়। অ্যাপ চালু থাকলে এক্সটেনশন ডাউনলোড ধরবে।",
    removeTitle: "তালিকা থেকে সরাবেন?", deleteFile: "ডিস্ক থেকে ফাইলও মুছুন", remove: "সরান",
    queued: "অপেক্ষায়", downloading: "ডাউনলোড হচ্ছে", paused: "থামানো", completed: "সম্পন্ন", error: "ত্রুটি",
    elapsed: "সময়", left: "বাকি", of: "/", files: "টি ফাইল", noResume: "রিজিউম নেই",
    pause: "থামান", resume: "চালু করুন", retry: "আবার চেষ্টা", openFile: "ফাইল খুলুন", openFolder: "ফোল্ডার", del: "সরান",
    pasteFirst: "কোনো লিংক দিন",
    categorize: "ফাইলের ধরন অনুযায়ী ফোল্ডারে সাজান", miniWin: "ডাউনলোডের সময় ভাসমান ছোট উইন্ডো দেখান",
    autostart: "Windows চালু হলে নিজে থেকে চালু হোক",
    cat_video: "ভিডিও", cat_music: "গান / অডিও", cat_documents: "ডকুমেন্ট", cat_programs: "প্রোগ্রাম",
    cat_compressed: "কম্প্রেসড", cat_images: "ছবি", cat_other: "অন্যান্য",
  },
  en: {
    tagline: "lightning-fast downloader",
    add: "Add", resumeAll: "Resume all", pauseAll: "Pause all", settings: "Settings",
    tabAll: "All", tabActive: "Active", tabDone: "Completed",
    emptyTitle: "No downloads yet", emptyHint: "Press “Add” or paste a link",
    addTitle: "New download", links: "Links (one per line)", saveTo: "Save to", browse: "Browse",
    fileName: "File name", optional: "(optional)", cancel: "Cancel", download: "Download", save: "Save",
    defaultFolder: "Default folder", connections: "Connections per file", maxActive: "Simultaneous downloads",
    extNote: "The browser extension talks to this app on 127.0.0.1:6892. Keep the app running so the extension can capture downloads.",
    removeTitle: "Remove from list?", deleteFile: "Also delete the file from disk", remove: "Remove",
    queued: "Queued", downloading: "Downloading", paused: "Paused", completed: "Completed", error: "Error",
    elapsed: "time", left: "left", of: "/", files: "files", noResume: "no resume",
    pause: "Pause", resume: "Resume", retry: "Retry", openFile: "Open file", openFolder: "Folder", del: "Remove",
    pasteFirst: "Enter a link",
    categorize: "Sort files into folders by type", miniWin: "Show a floating mini window while downloading",
    autostart: "Start with Windows",
    cat_video: "Video", cat_music: "Music / audio", cat_documents: "Documents", cat_programs: "Programs",
    cat_compressed: "Compressed", cat_images: "Images", cat_other: "Other",
  },
};
let lang = "bn";
try { lang = localStorage.getItem("lang") || "bn"; } catch (_) {}
const t = (k) => (I18N[lang] && I18N[lang][k]) || k;

const BN_DIGITS = "০১২৩৪৫৬৭৮৯";
const num = (s) => (lang === "bn" ? String(s).replace(/\d/g, (d) => BN_DIGITS[d]) : String(s));

function applyLang() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach((e) => (e.textContent = t(e.dataset.i18n)));
  document.querySelectorAll("[data-i18n-title]").forEach((e) => (e.title = t(e.dataset.i18nTitle)));
  $("btnLang").textContent = lang === "bn" ? "EN" : "বাং";
  rows.forEach((r) => (r.sig = "")); // force re-render of rows
  render();
}

// ---------------------------------------------------------------- backend
const $ = (id) => document.getElementById(id);
const tauri = window.__TAURI__;
const invoke = (cmd, args) => tauri.core.invoke(cmd, args);

// ---------------------------------------------------------------- formatting
function fmtBytes(b) {
  if (b == null) return "?";
  const u = ["B", "KB", "MB", "GB", "TB"];
  let i = 0, v = b;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return num((i === 0 ? v.toFixed(0) : v.toFixed(v >= 100 ? 0 : 1)) + " " + u[i]);
}
function fmtSpeed(b) { return fmtBytes(b) + "/s"; }
function fmtEta(sec) {
  if (!isFinite(sec) || sec <= 0) return "";
  sec = Math.round(sec);
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  const u = lang === "bn" ? { h: "ঘ", m: "মি", s: "সে" } : { h: "h", m: "m", s: "s" };
  return num(h ? `${h}${u.h} ${m}${u.m}` : m ? `${m}${u.m} ${s}${u.s}` : `${s}${u.s}`);
}
const COLORS = ["#4da3ff", "#3ecf8e", "#ff7a18", "#b36bff", "#ff5d6c", "#2ec4b6", "#e6b800"];
function extOf(name) {
  const m = /\.([A-Za-z0-9]{1,5})$/.exec(name || "");
  return m ? m[1].toLowerCase() : "file";
}
function colorFor(ext) {
  let h = 0;
  for (const c of ext) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return COLORS[h % COLORS.length];
}

// ---------------------------------------------------------------- list rendering
let items = [];
let tab = "all";
const rows = new Map(); // id -> { el, sig, refs }

const ICON = { pause: "⏸", resume: "▶", retry: "↻", file: "📄", folder: "📂", del: "✕" };

function makeRow(id) {
  const el = document.createElement("div");
  el.className = "item";
  el.dataset.id = id;
  el.innerHTML = `
    <div class="ico"></div>
    <div class="body">
      <div class="name"></div>
      <div class="meta"></div>
      <div class="bar"><i></i></div>
    </div>
    <div class="acts"></div>`;
  return {
    el, sig: "",
    ico: el.querySelector(".ico"), name: el.querySelector(".name"), meta: el.querySelector(".meta"),
    bar: el.querySelector(".bar i"), acts: el.querySelector(".acts"),
  };
}

function actionButtons(v) {
  const b = [];
  const btn = (act, label, icon) => `<button data-act="${act}" title="${label}">${icon}</button>`;
  if (v.status === "downloading" || v.status === "queued") b.push(btn("pause", t("pause"), ICON.pause));
  if (v.status === "paused") b.push(btn("resume", t("resume"), ICON.resume));
  if (v.status === "error") b.push(btn("resume", t("retry"), ICON.retry));
  if (v.status === "completed") b.push(btn("open", t("openFile"), ICON.file));
  b.push(btn("folder", t("openFolder"), ICON.folder));
  b.push(btn("del", t("del"), ICON.del));
  return b.join("");
}

function updateRow(r, v) {
  const pct = v.total ? Math.min(100, (v.downloaded / v.total) * 100) : v.status === "completed" ? 100 : 0;
  const unknown = !v.total && v.status === "downloading";
  r.el.className = `item ${v.status}${unknown ? " indeterminate" : ""}`;
  r.bar.style.width = pct.toFixed(1) + "%";

  const parts = [`<span class="st-${v.status}">${t(v.status)}${(v.status === "downloading" || v.status === "paused") && v.total ? " " + num(pct.toFixed(0)) + "%" : ""}</span>`];
  if (v.total) parts.push(`${fmtBytes(v.downloaded)} ${t("of")} ${fmtBytes(v.total)}`);
  else if (v.downloaded) parts.push(fmtBytes(v.downloaded));
  if (v.status === "downloading" && v.speed > 0) {
    parts.push(fmtSpeed(v.speed));
    if (v.total) {
      const eta = fmtEta((v.total - v.downloaded) / v.speed);
      if (eta) parts.push(`${eta} ${t("left")}`);
    }
  }
  if ((v.status === "downloading" || v.status === "completed") && v.elapsed > 0) parts.push(`${t("elapsed")} ${fmtEta(v.elapsed)}`);
  if (v.status === "error" && v.error) parts.push(escapeHtml(v.error));
  if (v.status !== "completed" && v.total && !v.resumable) parts.push(t("noResume"));
  const metaHtml = parts.join(" · ");
  if (r.metaHtml !== metaHtml) { r.meta.innerHTML = metaHtml; r.metaHtml = metaHtml; }

  // slow-changing parts: only touch the DOM when they change
  const sig = `${v.filename}|${v.status}|${lang}|${v.resumable}`;
  if (r.sig !== sig) {
    r.sig = sig;
    const ext = extOf(v.filename);
    r.ico.textContent = ext.slice(0, 4);
    r.ico.style.background = colorFor(ext);
    r.name.textContent = v.filename;
    r.name.title = v.url;
    r.acts.innerHTML = actionButtons(v);
  }
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}

function visible(v) {
  if (tab === "active") return v.status !== "completed";
  if (tab === "done") return v.status === "completed";
  return true;
}

function render() {
  const list = $("list");
  const shown = items.filter(visible);
  const keep = new Set(shown.map((v) => v.id));
  for (const [id, r] of rows) {
    if (!keep.has(id)) { r.el.remove(); rows.delete(id); }
  }
  let prev = null;
  for (const v of shown) {
    let r = rows.get(v.id);
    if (!r) { r = makeRow(v.id); rows.set(v.id, r); }
    updateRow(r, v);
    const wanted = prev ? prev.nextSibling : list.firstChild;
    if (r.el !== wanted) list.insertBefore(r.el, wanted);
    prev = r.el;
  }
  const empty = shown.length === 0;
  $("empty").classList.toggle("hidden", !empty);
  list.classList.toggle("hidden", empty);

  const active = items.filter((v) => v.status === "downloading");
  $("fCount").textContent = `${num(items.length)} ${t("files")}`;
  const total = active.reduce((a, v) => a + v.speed, 0);
  $("fSpeed").textContent = active.length ? `⚡ ${fmtSpeed(total)}` : "";
}

async function poll() {
  try {
    items = await invoke("list");
    render();
  } catch (e) { console.error(e); }
}

// ---------------------------------------------------------------- row actions
$("list").addEventListener("click", async (e) => {
  const b = e.target.closest("button[data-act]");
  if (!b) return;
  const id = Number(b.closest(".item").dataset.id);
  const act = b.dataset.act;
  try {
    if (act === "pause") await invoke("pause", { id });
    else if (act === "resume") await invoke("resume", { id });
    else if (act === "open") await invoke("open_file", { id });
    else if (act === "folder") await invoke("open_folder", { id });
    else if (act === "del") return askDelete(id);
  } catch (err) { console.error(err); }
  poll();
});

// ---------------------------------------------------------------- dialogs
let settings = { dir: "", connections: 16, max_active: 3 };
const CAT_KEYS = ["video", "music", "documents", "programs", "compressed", "images", "other"];

async function pickFolder(input) {
  try {
    const dir = await tauri.dialog.open({ directory: true, defaultPath: input.value || undefined });
    if (dir) input.value = Array.isArray(dir) ? dir[0] : dir;
  } catch (e) { console.error(e); }
}

$("btnAdd").onclick = async () => {
  settings = await invoke("get_settings");
  $("addDir").value = settings.dir;
  $("addName").value = "";
  $("addErr").textContent = "";
  $("addUrls").value = "";
  $("dlgAdd").showModal();
  try {
    const clip = (await navigator.clipboard.readText()).trim();
    if (/^https?:\/\/\S+$/i.test(clip) && !$("addUrls").value) $("addUrls").value = clip;
  } catch (_) {}
  $("addUrls").focus();
};
$("addBrowse").onclick = () => pickFolder($("addDir"));
$("addCancel").onclick = () => $("dlgAdd").close();
$("formAdd").onsubmit = async (e) => {
  e.preventDefault();
  const text = $("addUrls").value.trim();
  if (!text) { $("addErr").textContent = t("pasteFirst"); return; }
  const dir = $("addDir").value.trim() || null;
  try {
    const lines = text.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
    const name = $("addName").value.trim();
    if (lines.length === 1) await invoke("add_download", { url: lines[0], dir, filename: name || null });
    else await invoke("add_many", { text, dir });
    $("dlgAdd").close();
    poll();
  } catch (err) { $("addErr").textContent = String(err); }
};

$("btnSettings").onclick = async () => {
  settings = await invoke("get_settings");
  $("setDir").value = settings.dir;
  $("setConn").value = settings.connections;
  $("setAct").value = settings.max_active;
  $("setConnV").textContent = num(settings.connections);
  $("setActV").textContent = num(settings.max_active);
  $("setCat").checked = settings.categorize !== false;
  $("setMini").checked = settings.mini_window !== false;
  $("setAuto").checked = settings.autostart !== false;
  const grid = $("catGrid");
  grid.innerHTML = "";
  CAT_KEYS.forEach((k) => {
    const l = document.createElement("label");
    const s = document.createElement("span");
    s.textContent = t("cat_" + k);
    const i = document.createElement("input");
    i.type = "text"; i.dataset.cat = k; i.spellcheck = false;
    i.value = (settings.categories && settings.categories[k]) || "";
    l.append(s, i);
    grid.append(l);
  });
  $("catGrid").hidden = !$("setCat").checked;
  $("dlgSet").showModal();
};
$("setCat").onchange = () => ($("catGrid").hidden = !$("setCat").checked);
$("setConn").oninput = () => ($("setConnV").textContent = num($("setConn").value));
$("setAct").oninput = () => ($("setActV").textContent = num($("setAct").value));
$("setBrowse").onclick = () => pickFolder($("setDir"));
$("setCancel").onclick = () => $("dlgSet").close();
$("formSet").onsubmit = async (e) => {
  e.preventDefault();
  await invoke("set_settings", {
    settings: {
      ...settings,
      dir: $("setDir").value.trim(),
      connections: Number($("setConn").value),
      max_active: Number($("setAct").value),
      categorize: $("setCat").checked,
      mini_window: $("setMini").checked,
      autostart: $("setAuto").checked,
      categories: Object.fromEntries([...document.querySelectorAll("#catGrid input")].map((i) => [i.dataset.cat, i.value.trim()])),
    },
  });
  $("dlgSet").close();
};

let delId = null;
function askDelete(id) {
  const v = items.find((x) => x.id === id);
  if (!v) return;
  delId = id;
  $("delName").textContent = v.filename;
  $("delFile").checked = false;
  $("dlgDel").showModal();
}
$("delCancel").onclick = () => $("dlgDel").close();
$("formDel").onsubmit = async (e) => {
  e.preventDefault();
  await invoke("remove", { id: delId, deleteFile: $("delFile").checked });
  $("dlgDel").close();
  poll();
};

// ---------------------------------------------------------------- toolbar
$("btnPauseAll").onclick = async () => { await invoke("pause_all"); poll(); };
$("btnResumeAll").onclick = async () => { await invoke("resume_all"); poll(); };
$("btnLang").onclick = () => {
  lang = lang === "bn" ? "en" : "bn";
  try { localStorage.setItem("lang", lang); } catch (_) {}
  applyLang();
};
document.querySelectorAll("#tabs button").forEach((b) => {
  b.onclick = () => {
    tab = b.dataset.tab;
    document.querySelectorAll("#tabs button").forEach((x) => x.classList.toggle("on", x === b));
    render();
  };
});

// Ctrl+V anywhere with a link on the clipboard opens the add dialog
document.addEventListener("paste", (e) => {
  if (document.querySelector("dialog[open]")) return;
  const txt = (e.clipboardData && e.clipboardData.getData("text")) || "";
  if (/^https?:\/\/\S+/i.test(txt.trim())) {
    $("btnAdd").click();
    setTimeout(() => { $("addUrls").value = txt.trim(); }, 50);
  }
});

applyLang();
poll();
setInterval(poll, 500);
