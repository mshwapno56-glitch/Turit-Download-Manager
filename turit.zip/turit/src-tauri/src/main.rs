#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use tauri::menu::{Menu, MenuItem};
use tauri::tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent};
use tauri::{AppHandle, Manager as _, State, WebviewUrl, WebviewWindowBuilder, WindowEvent};
use tauri_plugin_autostart::{MacosLauncher, ManagerExt as _};
use tauri_plugin_notification::NotificationExt as _;
use turit_engine::{server, Event, Manager, ReqHeaders, Settings, View};

const EXT_PORT: u16 = 6892;

/// engine + "user closed the mini window" flag
struct App(Manager, AtomicBool);

fn show_main(app: &AppHandle) {
    if let Some(w) = app.get_webview_window("main") {
        let _ = w.unminimize();
        let _ = w.show();
        let _ = w.set_focus();
    }
}

fn notify(app: &AppHandle, title: &str, body: &str) {
    let _ = app.notification().builder().title(title).body(body).show();
}

fn apply_autostart(app: &AppHandle, on: bool) {
    let al = app.autolaunch();
    let _ = if on { al.enable() } else { al.disable() };
}

#[tauri::command]
fn show_main_window(app: AppHandle) {
    show_main(&app);
}

#[tauri::command]
fn hide_mini(app: AppHandle, state: State<'_, App>) {
    state.1.store(true, Ordering::SeqCst);
    if let Some(w) = app.get_webview_window("mini") {
        let _ = w.hide();
    }
}

/// Watches downloads: notifications + the floating progress window.
fn supervise(app: AppHandle) {
    std::thread::spawn(move || {
        loop {
            std::thread::sleep(std::time::Duration::from_millis(700));
            let state = app.state::<App>();
            let mgr = &state.0;

            for ev in mgr.take_events() {
                match ev {
                    Event::Completed { filename, .. } => notify(&app, "Download complete · ডাউনলোড সম্পন্ন", &filename),
                    Event::Failed { filename, error } => {
                        notify(&app, "Download failed · ডাউনলোড ব্যর্থ", &format!("{filename}\n{error}"))
                    }
                }
            }

            let active = mgr.any_active();
            if !active {
                state.1.store(false, Ordering::SeqCst); // next download shows the window again
            }
            let main_hidden = app
                .get_webview_window("main")
                .map(|w| !w.is_visible().unwrap_or(true) || w.is_minimized().unwrap_or(false))
                .unwrap_or(true);
            let want = active && mgr.settings().mini_window && !state.1.load(Ordering::SeqCst) && main_hidden;

            let mini = app.get_webview_window("mini");
            if want {
                let w = match mini {
                    Some(w) => Some(w),
                    None => {
                        let mut b = WebviewWindowBuilder::new(&app, "mini", WebviewUrl::App("mini.html".into()))
                            .title("Turit")
                            .inner_size(320.0, 118.0)
                            .resizable(false)
                            .decorations(false)
                            .always_on_top(true)
                            .skip_taskbar(true)
                            .visible(false)
                            .focused(false);
                        if let Ok(Some(m)) = app.primary_monitor() {
                            let sf = m.scale_factor();
                            let sz = m.size();
                            b = b.position(sz.width as f64 / sf - 340.0, sz.height as f64 / sf - 190.0);
                        }
                        b.build().ok()
                    }
                };
                if let Some(w) = w {
                    if !w.is_visible().unwrap_or(false) {
                        let _ = w.show();
                    }
                }
            } else if let Some(w) = mini {
                if w.is_visible().unwrap_or(false) {
                    let _ = w.hide();
                }
            }
        }
    });
}

#[tauri::command]
fn list(app: State<'_, App>) -> Vec<View> {
    app.0.list()
}

#[tauri::command]
fn add_download(app: State<'_, App>, url: String, dir: Option<String>, filename: Option<String>) -> Result<u64, String> {
    app.0.add(url, ReqHeaders::default(), dir, filename)
}

/// Several links at once (one per line). Returns how many were added.
#[tauri::command]
fn add_many(app: State<'_, App>, text: String, dir: Option<String>) -> Result<usize, String> {
    let mut n = 0;
    let mut last_err = String::new();
    for line in text.lines().map(|l| l.trim()).filter(|l| !l.is_empty()) {
        match app.0.add(line.to_string(), ReqHeaders::default(), dir.clone(), None) {
            Ok(_) => n += 1,
            Err(e) => last_err = e,
        }
    }
    if n == 0 {
        Err(if last_err.is_empty() { "No link".into() } else { last_err })
    } else {
        Ok(n)
    }
}

#[tauri::command]
fn pause(app: State<'_, App>, id: u64) {
    app.0.pause(id)
}

#[tauri::command]
fn resume(app: State<'_, App>, id: u64) {
    app.0.resume(id)
}

#[tauri::command]
fn pause_all(app: State<'_, App>) {
    app.0.pause_all()
}

#[tauri::command]
fn resume_all(app: State<'_, App>) {
    app.0.resume_all()
}

#[tauri::command]
fn remove(app: State<'_, App>, id: u64, delete_file: bool) {
    app.0.remove(id, delete_file)
}

#[tauri::command]
fn get_settings(app: State<'_, App>) -> Settings {
    app.0.settings()
}

#[tauri::command]
fn set_settings(handle: AppHandle, app: State<'_, App>, settings: Settings) {
    let auto = settings.autostart;
    app.0.set_settings(settings);
    apply_autostart(&handle, auto);
}

#[tauri::command]
fn open_file(app: State<'_, App>, id: u64) -> Result<(), String> {
    let p = app.0.final_path(id).ok_or("not found")?;
    if !p.exists() {
        return Err("File not found".into());
    }
    open_path(&p, false)
}

#[tauri::command]
fn open_folder(app: State<'_, App>, id: u64) -> Result<(), String> {
    let p = app.0.final_path(id).ok_or("not found")?;
    if p.exists() {
        open_path(&p, true)
    } else {
        // not finished yet: open the folder only
        let dir = p.parent().ok_or("no folder")?;
        open_path(dir, false)
    }
}

#[cfg(windows)]
fn open_path(p: &Path, select: bool) -> Result<(), String> {
    use std::os::windows::process::CommandExt;
    const NO_WINDOW: u32 = 0x0800_0000;
    let mut c = std::process::Command::new("explorer.exe");
    if select {
        c.raw_arg(format!("/select,\"{}\"", p.display()));
    } else {
        c.arg(p);
    }
    c.creation_flags(NO_WINDOW);
    c.spawn().map(|_| ()).map_err(|e| e.to_string())
}

#[cfg(not(windows))]
fn open_path(p: &Path, select: bool) -> Result<(), String> {
    let target = if select { p.parent().unwrap_or(p) } else { p };
    std::process::Command::new("xdg-open").arg(target).spawn().map(|_| ()).map_err(|e| e.to_string())
}

fn main() {
    tauri::Builder::default()
        // must be first: a second launch just brings the running app forward
        .plugin(tauri_plugin_single_instance::init(|app, _args, _cwd| show_main(app)))
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_notification::init())
        .plugin(tauri_plugin_autostart::init(MacosLauncher::LaunchAgent, Some(vec!["--hidden"])))
        .on_window_event(|window, event| {
            // closing the main window keeps downloads running in the tray
            if window.label() == "main" {
                if let WindowEvent::CloseRequested { api, .. } = event {
                    api.prevent_close();
                    let _ = window.hide();
                }
            }
        })
        .setup(|app| {
            let data = app.path().app_data_dir()?;
            std::fs::create_dir_all(&data)?;
            // main folder: Downloads\Turit
            let downloads = app
                .path()
                .download_dir()
                .map(|p| p.join("Turit").to_string_lossy().to_string())
                .unwrap_or_else(|_| ".".to_string());
            let mgr = tauri::async_runtime::block_on(async { Manager::new(data.join("state.json"), downloads) });
            // where yt-dlp.exe / ffmpeg.exe live (installed next to the app)
            let mut tool_dirs: Vec<std::path::PathBuf> = vec![];
            if let Ok(r) = app.path().resource_dir() {
                tool_dirs.push(r.join("bin"));
                tool_dirs.push(r);
            }
            if let Ok(exe) = std::env::current_exe() {
                if let Some(d) = exe.parent() {
                    tool_dirs.push(d.join("bin"));
                    tool_dirs.push(d.to_path_buf());
                }
            }
            mgr.set_tools_dirs(tool_dirs);
            mgr.update_ytdlp();
            let autostart = mgr.settings().autostart;
            let for_server = mgr.clone();
            tauri::async_runtime::spawn(async move {
                if let Err(e) = server::serve(for_server, EXT_PORT).await {
                    eprintln!("browser link server not started: {e}");
                }
            });
            app.manage(App(mgr, AtomicBool::new(false)));

            apply_autostart(app.handle(), autostart);

            // tray icon: left click opens, menu has Open / Quit
            let open_i = MenuItem::with_id(app, "open", "Open Turit", true, None::<&str>)?;
            let quit_i = MenuItem::with_id(app, "quit", "Quit (stops downloads)", true, None::<&str>)?;
            let menu = Menu::with_items(app, &[&open_i, &quit_i])?;
            let mut tray = TrayIconBuilder::new()
                .tooltip("Turit")
                .menu(&menu)
                .show_menu_on_left_click(false)
                .on_menu_event(|app, event| match event.id.as_ref() {
                    "open" => show_main(app),
                    "quit" => app.exit(0),
                    _ => {}
                })
                .on_tray_icon_event(|tray, event| {
                    if let TrayIconEvent::Click { button: MouseButton::Left, button_state: MouseButtonState::Up, .. } = event {
                        show_main(tray.app_handle());
                    }
                });
            if let Some(icon) = app.default_window_icon() {
                tray = tray.icon(icon.clone());
            }
            tray.build(app)?;

            // started by Windows at login: stay in the tray
            if std::env::args().any(|a| a == "--hidden") {
                if let Some(w) = app.get_webview_window("main") {
                    let _ = w.hide();
                }
            }

            supervise(app.handle().clone());
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            list,
            add_download,
            add_many,
            pause,
            resume,
            pause_all,
            resume_all,
            remove,
            get_settings,
            set_settings,
            open_file,
            open_folder,
            show_main_window,
            hide_mini
        ])
        .run(tauri::generate_context!())
        .expect("error while running Turit");
}
