"use strict";
const tauri = window.__TAURI__;
const invoke = (cmd, args) => tauri.core.invoke(cmd, args);
const $ = (id) => document.getElementById(id);

let lang = "bn";
try { lang = localStorage.getItem("lang") || "bn"; } catch (_) {}
const BN = "০১২৩৪৫৬৭৮৯";
const num = (s) => (lang === "bn" ? String(s).replace(/\d/g, (d) => BN[d]) : String(s));
const L = lang === "bn"
  ? { h: "ঘ", m: "মি", s: "সে", time: "সময়", left: "বাকি", more: "আরও" }
  : { h: "h", m: "m", s: "s", time: "time", left: "left", more: "more" };

function bytes(b) {
  const u = ["B", "KB", "MB", "GB", "TB"];
  let i = 0, v = b;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return num((i === 0 ? v.toFixed(0) : v.toFixed(v >= 100 ? 0 : 1)) + " " + u[i]);
}
function dur(sec) {
  if (!isFinite(sec) || sec <= 0) return "";
  sec = Math.round(sec);
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return num(h ? `${h}${L.h} ${m}${L.m}` : m ? `${m}${L.m} ${s}${L.s}` : `${s}${L.s}`);
}

async function tick() {
  try {
    const all = await invoke("list");
    const act = all.filter((v) => v.status === "downloading");
    if (!act.length) return;
    const v = act[0];
    $("name").textContent = v.filename;
    const pct = v.total ? Math.min(100, (v.downloaded / v.total) * 100) : 0;
    $("fill").style.width = pct.toFixed(1) + "%";
    $("fill").className = v.total ? "fill" : "fill ind";
    $("pct").textContent = v.total ? num(pct.toFixed(0)) + "%" : bytes(v.downloaded);
    $("speed").textContent = v.speed > 0 ? bytes(v.speed) + "/s" : "";
    $("elapsed").textContent = v.elapsed > 0 ? `${L.time} ${dur(v.elapsed)}` : "";
    const eta = v.total && v.speed > 0 ? dur((v.total - v.downloaded) / v.speed) : "";
    $("left").textContent = eta ? `${eta} ${L.left}` : "";
    $("more").textContent = act.length > 1 ? `+${num(act.length - 1)} ${L.more}` : "";
  } catch (e) { /* app not ready */ }
}
$("open").onclick = () => invoke("show_main_window");
$("close").onclick = () => invoke("hide_mini");
tick();
setInterval(tick, 500);
