"use strict";
const T = window.__TAURI__ || window.parent.__TAURI__;
const invoke = T.core.invoke;
const $ = (id) => document.getElementById(id);

const PRESETS = [
  { id: "basic", name: "Basic keypad phone", desc: "3GP · 176×144 · H.263 + AMR · smallest files" },
  { id: "standard", name: "Standard keypad phone", desc: "MP4 · 320×240 · H.264 + AAC" },
  { id: "large", name: "Large-screen keypad (Symphony, Walton, Nokia)", desc: "MP4 · 480×272 · H.264 + AAC" },
  { id: "legacy", name: "Very old phone / Java", desc: "3GP · 320×240 · MPEG-4 + AAC" },
  { id: "mp3", name: "Audio only — MP3", desc: "MP3 · 128 kbps" },
  { id: "amr", name: "Audio only — AMR", desc: "AMR · tiny files for basic phones" },
  { id: "custom", name: "Custom", desc: "Choose size, codec and bitrate yourself" },
];

const state = {
  files: new Map(), // id -> {id,path,name,size,status,progress,message,output,el}
  paths: new Set(),
  nextId: 1,
  running: false,
  cpus: 4,
  lastOutput: "",
};

/* ---------- persistence ---------- */
function load() { try { return JSON.parse(localStorage.getItem("turit_conv") || "{}"); } catch { return {}; } }
function save() {
  try {
    localStorage.setItem("turit_conv", JSON.stringify({
      preset: state.preset, outMode: outMode(), outDir: $("outDir").value, parallel: $("parallel").value,
      custom: customValues(),
    }));
  } catch {}
}
const saved = load();
state.preset = saved.preset || "standard";

/* ---------- helpers ---------- */
function fmtSize(b) {
  if (b < 1024 * 1024) return Math.max(1, Math.round(b / 1024)) + " KB";
  if (b < 1024 ** 3) return (b / 1024 / 1024).toFixed(1) + " MB";
  return (b / 1024 ** 3).toFixed(2) + " GB";
}
const outMode = () => document.querySelector('input[name="out"]:checked').value;

function customValues() {
  return {
    kind: $("cKind").value, container: $("cContainer").value, vcodec: $("cVcodec").value,
    width: +$("cW").value || 320, height: +$("cH").value || 240, fps: +$("cFps").value || 15,
    vkbps: +$("cVk").value || 250, acodec: $("cAcodec").value, akbps: +$("cAk").value || 64,
  };
}
function applyCustom(c) {
  if (!c) return;
  $("cKind").value = c.kind || "video"; $("cContainer").value = c.container || "mp4";
  $("cVcodec").value = c.vcodec || "h264"; $("cW").value = c.width || 320; $("cH").value = c.height || 240;
  $("cFps").value = c.fps || 15; $("cVk").value = c.vkbps || 250; $("cAcodec").value = c.acodec || "aac";
  $("cAk").value = c.akbps || 64;
}

/* ---------- presets UI ---------- */
function renderPresets() {
  const box = $("presets");
  box.innerHTML = "";
  for (const p of PRESETS) {
    const d = document.createElement("div");
    d.className = "preset" + (p.id === state.preset ? " sel" : "");
    d.innerHTML = `<b></b><span></span>`;
    d.firstChild.textContent = p.name;
    d.lastChild.textContent = p.desc;
    d.onclick = () => { if (state.running) return; state.preset = p.id; renderPresets(); save(); };
    box.appendChild(d);
  }
  $("customBox").hidden = state.preset !== "custom";
  $("cVideo").hidden = $("cKind").value === "audio";
}

/* ---------- file list ---------- */
function addEntries(entries) {
  let added = 0;
  for (const e of entries) {
    const key = e.path.toLowerCase();
    if (state.paths.has(key)) continue;
    state.paths.add(key);
    const f = { id: state.nextId++, path: e.path, name: e.name, size: e.size, status: "queued", progress: 0, message: "", output: "" };
    f.el = makeRow(f);
    state.files.set(f.id, f);
    $("list").appendChild(f.el.row);
    added++;
  }
  refresh();
  return added;
}

function makeRow(f) {
  const row = document.createElement("div");
  row.className = "item";
  row.innerHTML = `<div class="name"></div><div class="size"></div><div class="st"><div class="t">Waiting</div><div class="bar"><div class="fill"></div></div></div><button class="x" title="Remove">✕</button>`;
  const [name, size, st, x] = row.children;
  name.textContent = f.name; name.title = f.path; size.textContent = fmtSize(f.size);
  x.onclick = () => removeFile(f.id);
  return { row, st, t: st.querySelector(".t"), fill: st.querySelector(".fill"), x };
}

function paintRow(f) {
  const { st, t, fill } = f.el;
  st.className = "st " + f.status;
  fill.style.width = (f.status === "done" ? 100 : f.progress) + "%";
  const msg = f.message ? f.message : "";
  t.textContent = { queued: "Waiting", running: f.progress > 0 ? Math.round(f.progress) + "%" : "Converting…", done: "Done ✓", failed: "Failed", cancelled: "Cancelled" }[f.status];
  let m = st.querySelector(".msg");
  if (f.status === "failed" && msg) {
    if (!m) { m = document.createElement("div"); m.className = "msg"; st.appendChild(m); }
    m.textContent = msg; m.title = msg;
  } else if (m) m.remove();
}

function removeFile(id) {
  if (state.running) return;
  const f = state.files.get(id);
  if (!f) return;
  f.el.row.remove(); state.files.delete(id); state.paths.delete(f.path.toLowerCase());
  refresh();
}

function refresh() {
  const n = state.files.size;
  $("empty").hidden = n > 0;
  $("list").hidden = n === 0;
  let done = 0, failed = 0, sum = 0;
  for (const f of state.files.values()) {
    if (f.status === "done") { done++; sum += 100; }
    else if (f.status === "failed") { failed++; sum += 100; }
    else sum += f.progress;
  }
  const pct = n ? sum / n : 0;
  $("overallBar").style.width = pct + "%";
  $("overallText").textContent = n === 0 ? "No files yet"
    : `${n} file${n > 1 ? "s" : ""} · ${done} done${failed ? " · " + failed + " failed" : ""} · ${Math.round(pct)}%`;
  $("start").disabled = n === 0 || state.running;
}

/* ---------- adding files ---------- */
async function addPaths(paths) {
  if (!paths || !paths.length || state.running) return;
  const entries = await invoke("conv_scan_paths", { paths });
  const added = addEntries(entries);
  if (!added) note(entries.length ? "Those files are already in the list." : "No video or audio files found there.");
}

async function pick(directory) {
  const sel = await T.dialog.open({
    multiple: true, directory,
    filters: directory ? undefined : [{ name: "Video & audio", extensions: ["mp4","mkv","avi","mov","wmv","flv","webm","3gp","3g2","mpg","mpeg","m4v","ts","mts","m2ts","vob","ogv","divx","rmvb","rm","asf","mp3","wav","aac","m4a","flac","ogg","wma","amr","opus"] }],
  });
  if (!sel) return;
  await addPaths(Array.isArray(sel) ? sel : [sel]);
}

function note(msg) {
  const n = $("notice");
  n.textContent = msg; n.hidden = !msg;
}

/* ---------- convert ---------- */
async function start() {
  const todo = [...state.files.values()].filter((f) => f.status !== "done");
  if (!todo.length) { note("Everything in the list is already converted."); return; }
  if (outMode() === "custom" && !$("outDir").value) { note("Please choose an output folder first."); return; }
  note(""); $("summary").hidden = true;
  for (const f of todo) { f.status = "queued"; f.progress = 0; f.message = ""; paintRow(f); }
  setRunning(true);
  try {
    await invoke("conv_start", {
      jobs: todo.map((f) => ({ id: f.id, path: f.path })),
      settings: {
        preset: state.preset, custom: customValues(),
        output_dir: outMode() === "custom" ? $("outDir").value : "",
        parallel: +$("parallel").value,
      },
    });
  } catch (e) {
    setRunning(false); note(String(e));
  }
  save();
}

function setRunning(r) {
  state.running = r;
  $("start").hidden = r; $("stop").hidden = !r; $("stop").disabled = false; $("stop").textContent = "Stop";
  for (const id of ["addFiles", "addFolder", "removeDone", "clearAll", "browseOut"]) $(id).disabled = r || (id === "browseOut" && outMode() !== "custom");
  document.querySelectorAll(".x").forEach((b) => (b.style.visibility = r ? "hidden" : "visible"));
  refresh();
}

/* the converter lives in a tab of Turit: ignore drops while the Downloads tab is showing */
const visible = () => document.documentElement.getClientRects().length > 0;

/* ---------- init ---------- */
async function init() {
  renderPresets();
  applyCustom(saved.custom);
  renderPresets();

  const info = await invoke("conv_app_info");
  state.cpus = info.cpus;
  const eng = $("engine");
  if (!info.ffmpeg_ok) { eng.textContent = "FFmpeg not found — reinstall the app"; eng.classList.add("bad"); $("start").disabled = true; }
  else eng.textContent = info.version.replace(/^ffmpeg version\s*/i, "FFmpeg ").split(" Copyright")[0];

  const auto = Math.min(4, Math.max(1, Math.floor(info.cpus / 2)));
  const sel = $("parallel");
  sel.innerHTML = `<option value="${auto}">Auto (${auto})</option>` + [1, 2, 3, 4, 6, 8].map((n) => `<option value="${n}">${n}</option>`).join("");
  if (saved.parallel) sel.value = saved.parallel;

  if (saved.outMode === "custom") {
    document.querySelector('input[name="out"][value="custom"]').checked = true;
  }
  if (saved.outDir) $("outDir").value = saved.outDir;
  syncOut();

  // events
  await T.event.listen("job-update", (e) => {
    const u = e.payload, f = state.files.get(u.id);
    if (!f) return;
    f.status = u.status; f.progress = u.progress; f.message = u.message;
    if (u.status === "done" && u.output) state.lastOutput = u.output;
    paintRow(f); refresh();
  });
  await T.event.listen("notice", (e) => note(e.payload));
  await T.event.listen("batch-done", (e) => {
    const b = e.payload;
    setRunning(false);
    const s = $("summary");
    s.hidden = false;
    s.innerHTML = "";
    const p = document.createElement("div");
    p.textContent = `Finished: ${b.done} converted` + (b.failed ? `, ${b.failed} failed` : "") + (b.cancelled ? `, ${b.cancelled} cancelled` : "") + ".";
    s.appendChild(p);
    if (b.done && state.lastOutput) {
      const btn = document.createElement("button");
      btn.className = "btn"; btn.textContent = "Open output folder";
      btn.onclick = () => invoke("conv_open_folder", { path: state.lastOutput });
      s.appendChild(btn);
    }
  });

  // drag & drop from Explorer
  try {
    await T.webview.getCurrentWebview().onDragDropEvent((e) => {
      const t = e.payload.type;
      if (!visible()) return;
      if (t === "enter" || t === "over") $("drop").classList.add("over");
      else if (t === "leave") $("drop").classList.remove("over");
      else if (t === "drop") { $("drop").classList.remove("over"); if (visible()) addPaths(e.payload.paths); }
    });
  } catch (err) { console.warn("drag-drop unavailable", err); }
}

function syncOut() {
  const custom = outMode() === "custom";
  $("outDir").disabled = !custom; $("browseOut").disabled = !custom || state.running;
}

$("addFiles").onclick = () => pick(false);
$("addFolder").onclick = () => pick(true);
$("clearAll").onclick = () => { if (state.running) return; state.files.clear(); state.paths.clear(); $("list").innerHTML = ""; $("summary").hidden = true; refresh(); };
$("removeDone").onclick = () => { if (state.running) return; for (const f of [...state.files.values()]) if (f.status === "done") removeFile(f.id); };
$("start").onclick = start;
$("stop").onclick = async () => { $("stop").disabled = true; $("stop").textContent = "Stopping…"; await invoke("conv_cancel"); };
$("browseOut").onclick = async () => {
  const d = await T.dialog.open({ directory: true, multiple: false });
  if (d) { $("outDir").value = d; save(); }
};
document.querySelectorAll('input[name="out"]').forEach((r) => (r.onchange = () => { syncOut(); save(); }));
$("cKind").onchange = () => { renderPresets(); save(); };
["cContainer","cVcodec","cW","cH","cFps","cVk","cAcodec","cAk","parallel"].forEach((id) => ($(id).onchange = save));

init().catch((e) => { $("engine").textContent = "Startup error: " + e; $("engine").classList.add("bad"); });
