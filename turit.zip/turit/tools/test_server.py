"""Local test server with HTTP Range support, to try Turit without internet.
   python tools/test_server.py   ->  http://127.0.0.1:8099/big.bin (200 MB, 5 MB/s per connection)
"""
import http.server, socketserver, time, re

SIZE = 200 * 1024 * 1024
RATE = 5 * 1024 * 1024  # bytes/sec per connection

class H(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def do_GET(self):
        start, end, code = 0, SIZE - 1, 200
        m = re.match(r"bytes=(\d+)-(\d*)", self.headers.get("Range", ""))
        if m:
            start = int(m.group(1)); end = int(m.group(2)) if m.group(2) else SIZE - 1
            end = min(end, SIZE - 1); code = 206
        n = end - start + 1
        self.send_response(code)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Disposition", 'attachment; filename="test big.bin"')
        self.send_header("Content-Length", str(n))
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{SIZE}")
        self.end_headers()
        sent, chunk = 0, 64 * 1024
        try:
            while sent < n:
                k = min(chunk, n - sent)
                self.wfile.write(b"x" * k)
                sent += k
                time.sleep(k / RATE)
        except (BrokenPipeError, ConnectionResetError):
            pass

class S(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True

print("serving http://127.0.0.1:8099/big.bin")
S(("127.0.0.1", 8099), H).serve_forever()
