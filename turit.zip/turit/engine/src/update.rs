//! "Is there a newer version?" check.
//! Reads a tiny JSON file: {"version": "0.3.0", "notes": "what changed"}

use serde::{Deserialize, Serialize};
use std::time::Duration;

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct UpdateInfo {
    pub version: String,
    #[serde(default)]
    pub notes: String,
}

fn parts(v: &str) -> Vec<u64> {
    v.trim()
        .trim_start_matches(|c| c == 'v' || c == 'V')
        .split('.')
        .map(|p| p.chars().take_while(|c| c.is_ascii_digit()).collect::<String>().parse().unwrap_or(0))
        .collect()
}

/// true when `latest` is a higher version number than `current`
pub fn is_newer(latest: &str, current: &str) -> bool {
    let (a, b) = (parts(latest), parts(current));
    for i in 0..a.len().max(b.len()) {
        let x = a.get(i).copied().unwrap_or(0);
        let y = b.get(i).copied().unwrap_or(0);
        if x != y {
            return x > y;
        }
    }
    false
}

/// Some(info) only when a newer version is published. Any error (offline, file missing) -> None.
pub async fn check(url: &str, current: &str) -> Option<UpdateInfo> {
    let client = reqwest::Client::builder().timeout(Duration::from_secs(15)).build().ok()?;
    let resp = client.get(url).header("Cache-Control", "no-cache").send().await.ok()?;
    if !resp.status().is_success() {
        return None;
    }
    let text = resp.text().await.ok()?;
    let info: UpdateInfo = serde_json::from_str(&text).ok()?;
    if is_newer(&info.version, current) {
        Some(info)
    } else {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn compare() {
        assert!(is_newer("0.3.0", "0.2.0"));
        assert!(is_newer("v1.0", "0.9.9"));
        assert!(is_newer("0.2.1", "0.2"));
        assert!(!is_newer("0.2.0", "0.2.0"));
        assert!(!is_newer("0.1.9", "0.2.0"));
    }
}
