# Downloads the helper programs that get bundled into the installer:
#   yt-dlp (video sites), ffmpeg (joins video+audio), deno (JavaScript runtime yt-dlp needs for YouTube)
$ErrorActionPreference = "Stop"
$bin = Join-Path $PSScriptRoot "..\src-tauri\bin"
New-Item -ItemType Directory -Force $bin | Out-Null
$tmp = Join-Path $env:TEMP ("turit-tools-" + [guid]::NewGuid())
New-Item -ItemType Directory -Force $tmp | Out-Null

Invoke-WebRequest https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe -OutFile (Join-Path $bin "yt-dlp.exe")

$rel = Invoke-RestMethod https://api.github.com/repos/GyanD/codexffmpeg/releases/latest
$asset = $rel.assets | Where-Object { $_.name -like "*essentials_build.zip" } | Select-Object -First 1
Invoke-WebRequest $asset.browser_download_url -OutFile (Join-Path $tmp "ffmpeg.zip")
Expand-Archive (Join-Path $tmp "ffmpeg.zip") -DestinationPath (Join-Path $tmp "ff")
$ff = Get-ChildItem -Recurse (Join-Path $tmp "ff") -Filter ffmpeg.exe | Select-Object -First 1
Copy-Item $ff.FullName (Join-Path $bin "ffmpeg.exe")

Invoke-WebRequest https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip -OutFile (Join-Path $tmp "deno.zip")
Expand-Archive (Join-Path $tmp "deno.zip") -DestinationPath (Join-Path $tmp "dn")
Copy-Item (Join-Path $tmp "dn\deno.exe") (Join-Path $bin "deno.exe")

Get-ChildItem $bin
