//! Bulk video/audio converter for button phones (runs inside Turit).

use crate::conv_engine as engine;
use crate::conv_engine::{Caps, Custom, FileEntry, RunError};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::Arc;
use tauri::{AppHandle, Emitter, Manager, State};

#[derive(Default)]
pub struct ConvState {
    pub cancel: Arc<AtomicBool>,
    pub running: Arc<AtomicBool>,
}

fn ffmpeg_path(app: &AppHandle) -> PathBuf {
    let mut cands: Vec<PathBuf> = Vec::new();
    if let Ok(r) = app.path().resource_dir() {
        cands.push(r.join("bin").join(engine::FFMPEG_NAME));
        cands.push(r.join(engine::FFMPEG_NAME));
    }
    if let Ok(exe) = std::env::current_exe() {
        if let Some(d) = exe.parent() {
            cands.push(d.join("bin").join(engine::FFMPEG_NAME));
            cands.push(d.join(engine::FFMPEG_NAME));
        }
    }
    cands
        .into_iter()
        .find(|p| p.is_file())
        .unwrap_or_else(|| PathBuf::from(engine::FFMPEG_NAME)) // fall back to PATH
}

#[derive(Serialize)]
pub struct AppInfo {
    ffmpeg_ok: bool,
    version: String,
    caps: Option<Caps>,
    cpus: usize,
}

#[tauri::command]
pub fn conv_app_info(app: AppHandle) -> AppInfo {
    let ff = ffmpeg_path(&app);
    let caps = engine::detect_caps(&ff);
    AppInfo {
        ffmpeg_ok: caps.is_some(),
        version: if caps.is_some() { engine::ffmpeg_version(&ff) } else { String::new() },
        caps,
        cpus: std::thread::available_parallelism().map(|n| n.get()).unwrap_or(2),
    }
}

#[tauri::command]
pub fn conv_scan_paths(paths: Vec<String>) -> Vec<FileEntry> {
    engine::scan(&paths)
}

#[derive(Deserialize)]
pub struct Job {
    id: usize,
    path: String,
}

#[derive(Deserialize)]
pub struct Settings {
    preset: String,
    #[serde(default)]
    custom: Custom,
    #[serde(default)]
    output_dir: String,
    #[serde(default)]
    parallel: usize,
}

#[derive(Serialize, Clone)]
pub struct JobUpdate {
    id: usize,
    status: &'static str, // running | done | failed | cancelled
    progress: f64,
    message: String,
    output: String,
}

#[derive(Serialize, Clone)]
pub struct BatchDone {
    done: usize,
    failed: usize,
    cancelled: usize,
}

#[tauri::command]
pub fn conv_start(
    app: AppHandle,
    state: State<'_, ConvState>,
    jobs: Vec<Job>,
    settings: Settings,
) -> Result<(), String> {
    if state.running.swap(true, Ordering::SeqCst) {
        return Err("A conversion is already running.".into());
    }
    let fail = |msg: String| {
        state.running.store(false, Ordering::SeqCst);
        Err(msg)
    };
    if jobs.is_empty() {
        return fail("No files to convert.".into());
    }
    let ff = ffmpeg_path(&app);
    let Some(caps) = engine::detect_caps(&ff) else {
        return fail("FFmpeg was not found or could not start.".into());
    };
    let (spec, note) = match engine::resolve(&settings.preset, &settings.custom, caps) {
        Ok(x) => x,
        Err(e) => return fail(e),
    };
    if let Some(n) = note {
        let _ = app.emit("notice", n);
    }

    state.cancel.store(false, Ordering::SeqCst);
    let files: Vec<(usize, String)> = jobs.iter().map(|j| (j.id, j.path.clone())).collect();
    let plan = Arc::new(engine::plan_outputs(&files, &settings.output_dir, &spec.ext));
    let spec = Arc::new(spec);
    let workers = settings.parallel.clamp(1, 8);
    let cancel = state.cancel.clone();
    let running = state.running.clone();

    std::thread::spawn(move || {
        let next = Arc::new(AtomicUsize::new(0));
        let (done, failed, cancelled) = (Arc::new(AtomicUsize::new(0)), Arc::new(AtomicUsize::new(0)), Arc::new(AtomicUsize::new(0)));
        let mut handles = Vec::new();
        for _ in 0..workers {
            let (plan, spec, next, cancel, app, ff) = (plan.clone(), spec.clone(), next.clone(), cancel.clone(), app.clone(), ff.clone());
            let (done, failed, cancelled) = (done.clone(), failed.clone(), cancelled.clone());
            handles.push(std::thread::spawn(move || loop {
                let i = next.fetch_add(1, Ordering::SeqCst);
                if i >= plan.len() {
                    break;
                }
                let (id, input, output) = &plan[i];
                let emit = |status: &'static str, progress: f64, message: String| {
                    let _ = app.emit("job-update", JobUpdate { id: *id, status, progress, message, output: output.clone() });
                };
                if cancel.load(Ordering::Relaxed) {
                    cancelled.fetch_add(1, Ordering::SeqCst);
                    emit("cancelled", 0.0, "Cancelled".into());
                    continue;
                }
                emit("running", 0.0, String::new());
                let mut last = -1.0f64;
                let res = engine::run_one(&ff, input, output, &spec, &cancel, |p| {
                    if p - last >= 1.0 {
                        last = p;
                        emit("running", p, String::new());
                    }
                });
                match res {
                    Ok(()) => {
                        done.fetch_add(1, Ordering::SeqCst);
                        emit("done", 100.0, String::new());
                    }
                    Err(RunError::Cancelled) => {
                        cancelled.fetch_add(1, Ordering::SeqCst);
                        emit("cancelled", 0.0, "Cancelled".into());
                    }
                    Err(RunError::Failed(m)) => {
                        failed.fetch_add(1, Ordering::SeqCst);
                        emit("failed", 0.0, m);
                    }
                }
            }));
        }
        for h in handles {
            let _ = h.join();
        }
        running.store(false, Ordering::SeqCst);
        let _ = app.emit(
            "batch-done",
            BatchDone {
                done: done.load(Ordering::SeqCst),
                failed: failed.load(Ordering::SeqCst),
                cancelled: cancelled.load(Ordering::SeqCst),
            },
        );
    });
    Ok(())
}

#[tauri::command]
pub fn conv_cancel(state: State<'_, ConvState>) {
    state.cancel.store(true, Ordering::SeqCst);
}

#[tauri::command]
pub fn conv_open_folder(path: String) {
    let p = PathBuf::from(&path);
    let dir = if p.is_dir() { p } else { p.parent().map(|x| x.to_path_buf()).unwrap_or(p) };
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        let _ = std::process::Command::new("explorer").arg(dir).creation_flags(0x0800_0000).spawn();
    }
    #[cfg(not(windows))]
    {
        let _ = std::process::Command::new("xdg-open").arg(dir).spawn();
    }
}

