//! Conversion engine: presets, FFmpeg argument building, file scanning, and the
//! single-file runner. No Tauri dependencies, so it can be unit-tested alone.
#![allow(dead_code)]

use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use std::io::{BufRead, BufReader};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};

pub const MEDIA_EXT: &[&str] = &[
    "mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "3gp", "3g2", "mpg", "mpeg", "m4v", "ts",
    "mts", "m2ts", "vob", "ogv", "divx", "rmvb", "rm", "asf", "mp3", "wav", "aac", "m4a", "flac",
    "ogg", "wma", "amr", "opus",
];

#[cfg(windows)]
pub const FFMPEG_NAME: &str = "ffmpeg.exe";
#[cfg(not(windows))]
pub const FFMPEG_NAME: &str = "ffmpeg";

pub fn new_cmd(program: &Path) -> Command {
    let mut c = Command::new(program);
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        c.creation_flags(0x0800_0000); // CREATE_NO_WINDOW
    }
    c
}

// ---------------------------------------------------------------- capabilities

#[derive(Clone, Copy, Debug, Serialize)]
pub struct Caps {
    pub x264: bool,
    pub amr: bool,
    pub mp3: bool,
}

pub fn detect_caps(ffmpeg: &Path) -> Option<Caps> {
    let out = new_cmd(ffmpeg)
        .args(["-hide_banner", "-encoders"])
        .stdin(Stdio::null())
        .output()
        .ok()?;
    if !out.status.success() {
        return None;
    }
    let t = String::from_utf8_lossy(&out.stdout);
    Some(Caps {
        x264: t.contains(" libx264 "),
        amr: t.contains(" libopencore_amrnb "),
        mp3: t.contains(" libmp3lame "),
    })
}

pub fn ffmpeg_version(ffmpeg: &Path) -> String {
    new_cmd(ffmpeg)
        .arg("-version")
        .stdin(Stdio::null())
        .output()
        .ok()
        .and_then(|o| String::from_utf8_lossy(&o.stdout).lines().next().map(|s| s.to_string()))
        .unwrap_or_default()
}

// ---------------------------------------------------------------- settings

#[derive(Deserialize, Clone, Debug, Default)]
#[serde(default)]
pub struct Custom {
    pub kind: String,      // "video" | "audio"
    pub vcodec: String,    // h264 | mpeg4 | h263
    pub container: String, // mp4 | 3gp | avi
    pub width: u32,
    pub height: u32,
    pub fps: u32,
    pub vkbps: u32,
    pub acodec: String, // aac | amr | mp3
    pub akbps: u32,
}

#[derive(Clone, Debug)]
pub struct Spec {
    pub video: bool,
    pub ext: String,
    pub vcodec: String, // h264 | mpeg4 | h263
    pub w: u32,
    pub h: u32,
    pub fps: u32,
    pub vk: u32,
    pub acodec: String, // aac | amr | mp3
    pub ak: u32,
    pub ar: u32,
    pub ac: u32,
}

fn even(v: u32) -> u32 {
    let v = v.clamp(16, 4096);
    v - (v % 2)
}

fn snap_h263(w: u32, h: u32) -> (u32, u32) {
    let sizes = [(128u32, 96u32), (176, 144), (352, 288), (704, 576), (1408, 1152)];
    let want = (w as i64) * (h as i64);
    let mut best = sizes[1];
    let mut diff = i64::MAX;
    for s in sizes {
        let d = ((s.0 as i64) * (s.1 as i64) - want).abs();
        if d < diff {
            diff = d;
            best = s;
        }
    }
    best
}

fn video_spec(ext: &str, vcodec: &str, w: u32, h: u32, fps: u32, vk: u32, ac: &str, ak: u32, ch: u32) -> Spec {
    let (ar, ak) = if ac == "amr" { (8000, 12) } else { (44100, ak) };
    Spec {
        video: true,
        ext: ext.into(),
        vcodec: vcodec.into(),
        w,
        h,
        fps,
        vk,
        acodec: ac.into(),
        ak,
        ar,
        ac: if ac == "amr" { 1 } else { ch },
    }
}

fn audio_spec(ac: &str, ak: u32, ch: u32) -> Spec {
    let ext = match ac {
        "mp3" => "mp3",
        "amr" => "amr",
        _ => "m4a",
    };
    let (ar, ak, ch) = if ac == "amr" { (8000, 12, 1) } else { (44100, ak, ch) };
    Spec {
        video: false,
        ext: ext.into(),
        vcodec: String::new(),
        w: 0,
        h: 0,
        fps: 0,
        vk: 0,
        acodec: ac.into(),
        ak,
        ar,
        ac: ch,
    }
}

/// Turn a preset id (+ custom values) into a concrete spec, applying fallbacks
/// when the bundled FFmpeg lacks an encoder. Returns an optional notice.
pub fn resolve(preset: &str, custom: &Custom, caps: Caps) -> Result<(Spec, Option<String>), String> {
    let mut s = match preset {
        "basic" => video_spec("3gp", "h263", 176, 144, 15, 128, "amr", 12, 1),
        "standard" => video_spec("mp4", "h264", 320, 240, 20, 250, "aac", 64, 1),
        "large" => video_spec("mp4", "h264", 480, 272, 24, 450, "aac", 96, 2),
        "legacy" => video_spec("3gp", "mpeg4", 320, 240, 15, 250, "aac", 64, 1),
        "mp3" => audio_spec("mp3", 128, 2),
        "amr" => audio_spec("amr", 12, 1),
        "custom" => {
            if custom.kind == "audio" {
                audio_spec(&custom.acodec, custom.akbps.clamp(8, 320), 2)
            } else {
                let ext = match custom.container.as_str() {
                    "3gp" => "3gp",
                    "avi" => "avi",
                    _ => "mp4",
                };
                let vc = match custom.vcodec.as_str() {
                    "mpeg4" => "mpeg4",
                    "h263" => "h263",
                    _ => "h264",
                };
                let mut sp = video_spec(
                    ext,
                    vc,
                    even(custom.width),
                    even(custom.height),
                    custom.fps.clamp(5, 60),
                    custom.vkbps.clamp(30, 8000),
                    &custom.acodec,
                    custom.akbps.clamp(8, 320),
                    if custom.acodec == "amr" { 1 } else { 2 },
                );
                if ext == "avi" && sp.acodec == "amr" {
                    sp.acodec = "mp3".into(); // AMR cannot live in AVI
                    sp.ar = 44100;
                    sp.ak = 64;
                    sp.ac = 1;
                }
                sp
            }
        }
        other => return Err(format!("Unknown preset: {other}")),
    };

    let mut notes: Vec<String> = Vec::new();
    if s.video {
        if s.vcodec == "h263" {
            let (w, h) = snap_h263(s.w, s.h);
            s.w = w;
            s.h = h;
        } else {
            s.w = even(s.w);
            s.h = even(s.h);
        }
        if s.vcodec == "h264" && !caps.x264 {
            s.vcodec = "mpeg4".into();
            notes.push("H.264 encoder not available in this FFmpeg build; used MPEG-4 instead.".into());
        }
    }
    if s.acodec == "amr" && !caps.amr {
        s.acodec = "aac".into();
        s.ar = 44100;
        s.ak = 32;
        if !s.video {
            s.ext = "m4a".into();
        }
        notes.push("AMR encoder not available in this FFmpeg build; used AAC instead.".into());
    }
    if s.acodec == "mp3" && !caps.mp3 {
        s.acodec = "aac".into();
        if !s.video {
            s.ext = "m4a".into();
        }
        notes.push("MP3 encoder not available in this FFmpeg build; used AAC instead.".into());
    }
    Ok((s, notes.first().cloned()))
}

pub fn build_args(input: &str, output: &str, s: &Spec) -> Vec<String> {
    let mut a: Vec<String> = ["-hide_banner", "-nostdin", "-nostats", "-y", "-progress", "pipe:1", "-i"]
        .iter()
        .map(|x| x.to_string())
        .collect();
    a.push(input.into());

    let mut push = |items: &[&str]| a.extend(items.iter().map(|x| x.to_string()));

    if s.video {
        push(&["-map", "0:v:0", "-map", "0:a:0?", "-sn", "-dn", "-map_chapters", "-1", "-map_metadata", "-1"]);
        let vf = format!(
            "scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1",
            w = s.w,
            h = s.h
        );
        push(&["-vf", &vf, "-r", &s.fps.to_string(), "-pix_fmt", "yuv420p"]);
        let vb = format!("{}k", s.vk);
        match s.vcodec.as_str() {
            "h264" => {
                push(&["-c:v", "libx264", "-profile:v", "baseline", "-level", "3.0", "-preset", "veryfast"]);
                push(&["-b:v", &vb, "-maxrate", &format!("{}k", s.vk * 3 / 2), "-bufsize", &format!("{}k", s.vk * 3)]);
            }
            "h263" => push(&["-c:v", "h263", "-b:v", &vb]),
            _ => {
                push(&["-c:v", "mpeg4", "-b:v", &vb, "-qmin", "2"]);
                if s.ext == "avi" {
                    push(&["-vtag", "xvid"]);
                }
            }
        }
        if s.ext == "mp4" || s.ext == "3gp" {
            push(&["-movflags", "+faststart"]);
        }
    } else {
        push(&["-vn", "-map", "0:a:0", "-sn", "-dn", "-map_chapters", "-1"]);
    }

    let ab = format!("{}k", s.ak);
    let ar = s.ar.to_string();
    let ch = s.ac.to_string();
    match s.acodec.as_str() {
        "amr" => push(&["-c:a", "libopencore_amrnb", "-ar", "8000", "-ac", "1", "-b:a", "12200"]),
        "mp3" => push(&["-c:a", "libmp3lame", "-b:a", &ab, "-ar", &ar, "-ac", &ch]),
        _ => push(&["-c:a", "aac", "-b:a", &ab, "-ar", &ar, "-ac", &ch]),
    }
    a.push(output.into());
    a
}

// ---------------------------------------------------------------- files

#[derive(Serialize, Clone, Debug)]
pub struct FileEntry {
    pub path: String,
    pub name: String,
    pub size: u64,
}

fn is_media(p: &Path) -> bool {
    p.extension()
        .and_then(|e| e.to_str())
        .map(|e| MEDIA_EXT.contains(&e.to_ascii_lowercase().as_str()))
        .unwrap_or(false)
}

fn walk(dir: &Path, depth: u32, out: &mut Vec<FileEntry>) {
    if depth > 12 || out.len() > 20000 {
        return;
    }
    let Ok(rd) = std::fs::read_dir(dir) else { return };
    for e in rd.flatten() {
        let p = e.path();
        let Ok(md) = std::fs::metadata(&p) else { continue };
        if md.is_dir() {
            walk(&p, depth + 1, out);
        } else if is_media(&p) {
            out.push(FileEntry {
                path: p.to_string_lossy().into_owned(),
                name: p.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default(),
                size: md.len(),
            });
        }
    }
}

pub fn scan(paths: &[String]) -> Vec<FileEntry> {
    let mut out = Vec::new();
    for s in paths {
        let p = Path::new(s);
        if p.is_dir() {
            walk(p, 0, &mut out);
        } else if p.is_file() && is_media(p) {
            out.push(FileEntry {
                path: s.clone(),
                name: p.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default(),
                size: std::fs::metadata(p).map(|m| m.len()).unwrap_or(0),
            });
        }
    }
    out.sort_by(|a, b| a.path.to_lowercase().cmp(&b.path.to_lowercase()));
    out
}

/// Decide an output path for every input. Never overwrites: adds " (1)", " (2)"...
pub fn plan_outputs(files: &[(usize, String)], out_dir: &str, ext: &str) -> Vec<(usize, String, String)> {
    let mut taken: HashSet<String> = HashSet::new();
    let mut res = Vec::new();
    for (id, input) in files {
        let ip = Path::new(input);
        let dir: PathBuf = if out_dir.trim().is_empty() {
            ip.parent().unwrap_or(Path::new(".")).join("converted")
        } else {
            PathBuf::from(out_dir)
        };
        let stem = ip.file_stem().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(|| "output".into());
        let mut n = 0;
        let out = loop {
            let name = if n == 0 { format!("{stem}.{ext}") } else { format!("{stem} ({n}).{ext}") };
            let cand = dir.join(name);
            let key = cand.to_string_lossy().to_lowercase();
            if !cand.exists() && !taken.contains(&key) {
                taken.insert(key);
                break cand;
            }
            n += 1;
        };
        res.push((*id, input.clone(), out.to_string_lossy().into_owned()));
    }
    res
}

// ---------------------------------------------------------------- runner

fn parse_duration(line: &str) -> Option<f64> {
    let rest = line.split("Duration:").nth(1)?.trim();
    let t = rest.split(',').next()?.trim();
    let mut it = t.split(':');
    let h: f64 = it.next()?.parse().ok()?;
    let m: f64 = it.next()?.parse().ok()?;
    let s: f64 = it.next()?.parse().ok()?;
    Some(h * 3600.0 + m * 60.0 + s)
}

pub enum RunError {
    Cancelled,
    Failed(String),
}

/// Convert one file. `on_progress` receives 0..100 (only when duration is known).
pub fn run_one(
    ffmpeg: &Path,
    input: &str,
    output: &str,
    spec: &Spec,
    cancel: &AtomicBool,
    mut on_progress: impl FnMut(f64),
) -> Result<(), RunError> {
    if let Some(parent) = Path::new(output).parent() {
        std::fs::create_dir_all(parent).map_err(|e| RunError::Failed(format!("Cannot create output folder: {e}")))?;
    }
    let mut child = new_cmd(ffmpeg)
        .args(build_args(input, output, spec))
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|e| RunError::Failed(format!("Cannot start FFmpeg: {e}")))?;

    let duration = Arc::new(Mutex::new(0.0f64));
    let tail: Arc<Mutex<Vec<String>>> = Arc::new(Mutex::new(Vec::new()));
    let stderr = child.stderr.take().unwrap();
    let (d2, t2) = (duration.clone(), tail.clone());
    let err_thread = std::thread::spawn(move || {
        for line in BufReader::new(stderr).lines().map_while(Result::ok) {
            if line.contains("Duration:") {
                if let Some(d) = parse_duration(&line) {
                    let mut g = d2.lock().unwrap();
                    if *g == 0.0 {
                        *g = d;
                    }
                }
            }
            let l = line.trim().to_string();
            if !l.is_empty() {
                let mut g = t2.lock().unwrap();
                g.push(l);
                if g.len() > 8 {
                    g.remove(0);
                }
            }
        }
    });

    let stdout = child.stdout.take().unwrap();
    let mut was_cancelled = false;
    for line in BufReader::new(stdout).lines().map_while(Result::ok) {
        if cancel.load(Ordering::Relaxed) {
            was_cancelled = true;
            let _ = child.kill();
            break;
        }
        if let Some(v) = line.strip_prefix("out_time_us=") {
            if let Ok(us) = v.trim().parse::<f64>() {
                let d = *duration.lock().unwrap();
                if d > 0.0 {
                    on_progress((us / 1_000_000.0 / d * 100.0).clamp(0.0, 99.0));
                }
            }
        }
    }
    if cancel.load(Ordering::Relaxed) && !was_cancelled {
        was_cancelled = true;
        let _ = child.kill();
    }
    let status = child.wait();
    let _ = err_thread.join();

    if was_cancelled {
        let _ = std::fs::remove_file(output);
        return Err(RunError::Cancelled);
    }
    match status {
        Ok(s) if s.success() => Ok(()),
        _ => {
            let _ = std::fs::remove_file(output);
            let t = tail.lock().unwrap();
            let msg = t.iter().rev().take(2).rev().cloned().collect::<Vec<_>>().join(" | ");
            Err(RunError::Failed(if msg.is_empty() { "FFmpeg failed".into() } else { msg }))
        }
    }
}

// ---------------------------------------------------------------- tests

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn all_presets_convert_with_real_ffmpeg() {
        let ff = PathBuf::from("ffmpeg");
        let Some(caps) = detect_caps(&ff) else {
            eprintln!("ffmpeg not found, skipping");
            return;
        };
        eprintln!("caps: {caps:?}");
        let dir = std::env::temp_dir().join("bpconv_test");
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        let src = dir.join("সোর্স test.mp4");
        let ok = Command::new("ffmpeg")
            .args(["-y", "-v", "error", "-f", "lavfi", "-i", "testsrc=size=1280x720:rate=25:duration=3"])
            .args(["-f", "lavfi", "-i", "sine=frequency=440:duration=3"])
            .args(["-c:v", "libx264", "-c:a", "aac", "-shortest"])
            .arg(&src)
            .status()
            .unwrap()
            .success();
        assert!(ok, "could not make test clip");

        let cancel = AtomicBool::new(false);
        let custom = Custom {
            kind: "video".into(),
            vcodec: "mpeg4".into(),
            container: "avi".into(),
            width: 320,
            height: 240,
            fps: 15,
            vkbps: 300,
            acodec: "mp3".into(),
            akbps: 64,
        };
        for preset in ["basic", "standard", "large", "legacy", "mp3", "amr", "custom"] {
            let (spec, note) = resolve(preset, &custom, caps).unwrap();
            let plan = plan_outputs(&[(0, src.to_string_lossy().into_owned())], dir.join("out").to_str().unwrap(), &spec.ext);
            let out = &plan[0].2;
            let mut last = 0.0;
            let r = run_one(&ff, &plan[0].1, out, &spec, &cancel, |p| last = p);
            match r {
                Ok(()) => {}
                Err(RunError::Failed(m)) => panic!("preset {preset} failed: {m}"),
                Err(RunError::Cancelled) => panic!("cancelled?"),
            }
            let size = std::fs::metadata(out).unwrap().len();
            assert!(size > 1000, "{preset} output too small");
            eprintln!("{preset}: ok -> {out} ({size} bytes) note={note:?} lastprogress={last}");
        }
        // second plan must not overwrite
        let spec = resolve("standard", &custom, caps).unwrap().0;
        let plan = plan_outputs(&[(0, src.to_string_lossy().into_owned())], dir.join("out").to_str().unwrap(), &spec.ext);
        assert!(plan[0].2.contains(" ("));
    }

    #[test]
    fn h263_sizes_snap() {
        assert_eq!(snap_h263(320, 240), (352, 288));
        assert_eq!(snap_h263(176, 144), (176, 144));
    }
}
