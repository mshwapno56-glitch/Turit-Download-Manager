//! Test driver: cargo run -p turit-engine --example cli -- <url> <dir> [conns] [pause]
use std::time::Duration;
use turit_engine::{Manager, ReqHeaders, Status};

#[tokio::main]
async fn main() {
    let a: Vec<String> = std::env::args().collect();
    let url = a[1].clone();
    let dir = a[2].clone();
    let conns: u32 = a.get(3).and_then(|s| s.parse().ok()).unwrap_or(8);
    let pause_test = a.get(4).map(|s| s == "pause").unwrap_or(false);

    let state = std::path::PathBuf::from(&dir).join("state.json");
    let m = Manager::new(state, dir.clone());
    let mut s = m.settings();
    s.connections = conns;
    m.set_settings(s);
    let id = m.add(url, ReqHeaders::default(), None, None).unwrap();
    let t0 = std::time::Instant::now();
    let mut paused_once = !pause_test;
    loop {
        tokio::time::sleep(Duration::from_millis(250)).await;
        let v = m.list().into_iter().find(|v| v.id == id).unwrap();
        println!(
            "{:?} {}/{} {:.1} MB/s {}",
            v.status,
            v.downloaded,
            v.total.unwrap_or(0),
            v.speed as f64 / 1e6,
            v.error.clone().unwrap_or_default()
        );
        if !paused_once && v.status == Status::Downloading && v.total.map(|t| v.downloaded > t / 3).unwrap_or(false) {
            println!("--- pause");
            m.pause(id);
            tokio::time::sleep(Duration::from_secs(2)).await;
            let v = m.list().into_iter().find(|v| v.id == id).unwrap();
            println!("--- paused at {} status {:?}", v.downloaded, v.status);
            m.resume(id);
            paused_once = true;
        }
        if matches!(v.status, Status::Completed | Status::Error) {
            println!("done in {:.2}s -> {}/{}", t0.elapsed().as_secs_f64(), v.dir, v.filename);
            break;
        }
    }
}
