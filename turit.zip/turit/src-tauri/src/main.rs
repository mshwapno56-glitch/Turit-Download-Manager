#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::path::Path;
use tauri::{Manager as _, State};
use turit_engine::{server, Manager, ReqHeaders, Settings, View};

const EXT_PORT: u16 = 6892;

struct App(Manager);

#[tauri::command]
fn list(app: State<'_, App>) -> Vec<View> {
    app.0.list()
}

#[tauri::command]
fn add_download(app: State<'_, App>, url: String, dir: Option<String>, filename: Option<String>) -> Result<u64, String> {
    app.0.add(url, ReqHeaders::default(), dir, filename)
}

/// Several links at once (one per line). Returns how many were added.
#[tauri::command]
fn add_many(app: State<'_, App>, text: String, dir: Option<String>) -> Result<usize, String> {
    let mut n = 0;
    let mut last_err = String::new();
    for line in text.lines().map(|l| l.trim()).filter(|l| !l.is_empty()) {
        match app.0.add(line.to_string(), ReqHeaders::default(), dir.clone(), None) {
            Ok(_) => n += 1,
            Err(e) => last_err = e,
        }
    }
    if n == 0 {
        Err(if last_err.is_empty() { "No link".into() } else { last_err })
    } else {
        Ok(n)
    }
}

#[tauri::command]
fn pause(app: State<'_, App>, id: u64) {
    app.0.pause(id)
}

#[tauri::command]
fn resume(app: State<'_, App>, id: u64) {
    app.0.resume(id)
}

#[tauri::command]
fn pause_all(app: State<'_, App>) {
    app.0.pause_all()
}

#[tauri::command]
fn resume_all(app: State<'_, App>) {
    app.0.resume_all()
}

#[tauri::command]
fn remove(app: State<'_, App>, id: u64, delete_file: bool) {
    app.0.remove(id, delete_file)
}

#[tauri::command]
fn get_settings(app: State<'_, App>) -> Settings {
    app.0.settings()
}

#[tauri::command]
fn set_settings(app: State<'_, App>, settings: Settings) {
    app.0.set_settings(settings)
}

#[tauri::command]
fn open_file(app: State<'_, App>, id: u64) -> Result<(), String> {
    let p = app.0.final_path(id).ok_or("not found")?;
    if !p.exists() {
        return Err("File not found".into());
    }
    open_path(&p, false)
}

#[tauri::command]
fn open_folder(app: State<'_, App>, id: u64) -> Result<(), String> {
    let p = app.0.final_path(id).ok_or("not found")?;
    if p.exists() {
        open_path(&p, true)
    } else {
        // not finished yet: open the folder only
        let dir = p.parent().ok_or("no folder")?;
        open_path(dir, false)
    }
}

#[cfg(windows)]
fn open_path(p: &Path, select: bool) -> Result<(), String> {
    use std::os::windows::process::CommandExt;
    const NO_WINDOW: u32 = 0x0800_0000;
    let mut c = std::process::Command::new("explorer.exe");
    if select {
        c.raw_arg(format!("/select,\"{}\"", p.display()));
    } else {
        c.arg(p);
    }
    c.creation_flags(NO_WINDOW);
    c.spawn().map(|_| ()).map_err(|e| e.to_string())
}

#[cfg(not(windows))]
fn open_path(p: &Path, select: bool) -> Result<(), String> {
    let target = if select { p.parent().unwrap_or(p) } else { p };
    std::process::Command::new("xdg-open").arg(target).spawn().map(|_| ()).map_err(|e| e.to_string())
}

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .setup(|app| {
            let data = app.path().app_data_dir()?;
            std::fs::create_dir_all(&data)?;
            let downloads = app
                .path()
                .download_dir()
                .map(|p| p.to_string_lossy().to_string())
                .unwrap_or_else(|_| ".".to_string());
            let mgr = tauri::async_runtime::block_on(async { Manager::new(data.join("state.json"), downloads) });
            // where yt-dlp.exe / ffmpeg.exe live (installed next to the app)
            let mut tool_dirs: Vec<std::path::PathBuf> = vec![];
            if let Ok(r) = app.path().resource_dir() {
                tool_dirs.push(r.join("bin"));
                tool_dirs.push(r);
            }
            if let Ok(exe) = std::env::current_exe() {
                if let Some(d) = exe.parent() {
                    tool_dirs.push(d.join("bin"));
                    tool_dirs.push(d.to_path_buf());
                }
            }
            mgr.set_tools_dirs(tool_dirs);
            mgr.update_ytdlp();
            let for_server = mgr.clone();
            tauri::async_runtime::spawn(async move {
                if let Err(e) = server::serve(for_server, EXT_PORT).await {
                    eprintln!("browser link server not started: {e}");
                }
            });
            app.manage(App(mgr));
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            list,
            add_download,
            add_many,
            pause,
            resume,
            pause_all,
            resume_all,
            remove,
            get_settings,
            set_settings,
            open_file,
            open_folder
        ])
        .run(tauri::generate_context!())
        .expect("error while running Turit");
}
