// Floating "Download" button on videos (like IDM). Talks to the Turit app via background.js.
(() => {
  if (window.__turitInjected) return;
  window.__turitInjected = true;

  const isYT = /(^|\.)youtube\.com$/.test(location.hostname);
  const BN = /^bn/i.test(navigator.language);
  const T = BN
    ? { dl: "ডাউনলোড", finding: "ভিডিওর কোয়ালিটি খুঁজছি… (প্রথমবার ১০–২০ সেকেন্ড লাগতে পারে)", pick: "কোয়ালিটি বাছুন", phone: "MP4 · ফোনে চলবে (H.264)", nophone: "কিছু ফোনে নাও চলতে পারে", added: "Turit-এ যোগ হয়েছে ✓", direct: "মূল ভিডিও ফাইল (সরাসরি)", noapp: "Turit অ্যাপ চালু করুন", close: "বন্ধ", retry: "আবার চেষ্টা" }
    : { dl: "Download", finding: "Finding qualities… (first time can take 10–20 s)", pick: "Choose quality", phone: "MP4 · plays on phones (H.264)", nophone: "may not play on some phones", added: "Added to Turit ✓", direct: "Original video file (direct)", noapp: "Start the Turit app", close: "Close", retry: "Retry" };

  const host = document.createElement("div");
  host.style.cssText = "all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647";
  const root = host.attachShadow({ mode: "closed" });
  root.innerHTML = `
  <style>
    * { box-sizing: border-box; font-family: "Segoe UI","Nirmala UI",system-ui,sans-serif; }
    #btn { position: fixed; touch-action: none; user-select: none; display: none; align-items: center; gap: 6px; padding: 7px 12px; border: 0; border-radius: 999px; cursor: pointer;
      background: linear-gradient(135deg,#ffb020,#ff7a18); color: #1b1200; font-weight: 700; font-size: 13px; box-shadow: 0 4px 14px rgba(0,0,0,.45); }
    #btn:hover { filter: brightness(1.08); }
    #menu { position: fixed; display: none; width: 280px; max-height: 70vh; overflow: auto; background: #151a24; color: #e8ecf4; border: 1px solid #2a3142;
      border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,.55); padding: 10px; font-size: 13px; }
    #menu h4 { margin: 0 0 2px; font-size: 13px; line-height: 1.3; word-break: break-word; }
    #menu .sub { color: #8b95ab; font-size: 11px; margin-bottom: 8px; }
    #menu .opt { display: flex; justify-content: space-between; align-items: center; width: 100%; margin: 4px 0; padding: 9px 11px; border: 1px solid #2a3142;
      border-radius: 8px; background: #1e2330; color: inherit; cursor: pointer; font-size: 13px; text-align: left; }
    #menu .opt:hover { border-color: #ffb020; background: #262d3d; }
    #menu .opt small { color: #8b95ab; }
    #menu .msg { padding: 8px 2px; line-height: 1.4; }
    #menu .ok { color: #3ecf8e; font-weight: 600; }
    #menu .bad { color: #ff5d6c; }
    #menu .x { float: right; background: none; border: 0; color: #8b95ab; cursor: pointer; font-size: 15px; }
  </style>
  <button id="btn">⚡ <span id="btnT"></span></button>
  <div id="menu"></div>`;
  const $ = (id) => root.getElementById(id);
  const btn = $("btn"), menu = $("menu");
  $("btnT").textContent = T.dl;

  let current = null; // the <video> element the button belongs to
  let hideTimer = 0;
  let overUi = false;

  const send = (msg) =>
    new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => resolve(chrome.runtime.lastError ? { ok: false, error: "app" } : r || { ok: false, error: "app" }));
      } catch (_) {
        resolve({ ok: false, error: "app" });
      }
    });

  const fmtSize = (b) => {
    if (!b) return "";
    const u = ["B", "KB", "MB", "GB"];
    let i = 0, v = b;
    while (v >= 1024 && i < 3) { v /= 1024; i++; }
    return (i === 0 ? v.toFixed(0) : v.toFixed(v >= 100 ? 0 : 1)) + " " + u[i];
  };

  // ask for the qualities as soon as the button shows, so the menu opens instantly on click
  const pending = new Map(); // page url -> Promise
  function loadFormats(url) {
    if (!pending.has(url)) {
      const p = send({ type: "formats", url, referer: url }).then((r) => {
        if (!r || !r.ok) pending.delete(url); // failed: next click tries again
        return r;
      });
      pending.set(url, p);
    }
    return pending.get(url);
  }

  function bigVideos() {
    return [...document.querySelectorAll("video")].filter((v) => {
      const r = v.getBoundingClientRect();
      return r.width >= 240 && r.height >= 135 && r.bottom > 0 && r.top < innerHeight && r.right > 0 && r.left < innerWidth;
    });
  }

  // where the user dragged the button to: offset from the video's top-right corner
  let off = null;
  try {
    chrome.storage.local.get("btnOff", (r) => {
      if (r && r.btnOff && typeof r.btnOff.x === "number" && typeof r.btnOff.y === "number") off = r.btnOff;
    });
  } catch (_) {}
  let dragging = false;

  function place(v) {
    const r = v.getBoundingClientRect();
    const w = 120;
    const ox = off ? off.x : -(w + 12);
    const oy = off ? off.y : isYT ? 64 : 12;
    const left = Math.max(4, Math.min(innerWidth - w - 8, r.right + ox));
    const top = Math.max(4, Math.min(innerHeight - 40, r.top + oy));
    btn.style.left = left + "px";
    btn.style.top = top + "px";
    btn.style.display = "flex";
    loadFormats(location.href);
  }

  function scheduleHide() {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      if (overUi || menu.style.display === "block") return;
      btn.style.display = "none";
    }, 2500);
  }

  let lastMove = 0;
  document.addEventListener(
    "mousemove",
    (e) => {
      const now = Date.now();
      if (now - lastMove < 120) return;
      lastMove = now;
      if (dragging) return;
      if (document.fullscreenElement) { btn.style.display = "none"; return; }
      const hit = bigVideos().find((v) => {
        const r = v.getBoundingClientRect();
        return e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
      });
      if (hit) {
        current = hit;
        if (menu.style.display !== "block") place(hit);
        scheduleHide();
      }
    },
    { passive: true, capture: true }
  );
  for (const el of [btn, menu]) {
    el.addEventListener("mouseenter", () => { overUi = true; clearTimeout(hideTimer); });
    el.addEventListener("mouseleave", () => { overUi = false; scheduleHide(); });
  }

  function openMenu(html) {
    const r = btn.getBoundingClientRect();
    menu.innerHTML = html;
    menu.style.display = "block";
    const mh = Math.min(menu.offsetHeight, innerHeight * 0.7);
    menu.style.left = Math.max(4, Math.min(innerWidth - 290, r.right - 280)) + "px";
    menu.style.top = Math.max(4, Math.min(innerHeight - mh - 8, r.bottom + 8)) + "px";
    const x = menu.querySelector(".x");
    if (x) x.onclick = closeMenu;
  }
  function closeMenu() { menu.style.display = "none"; scheduleHide(); }
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeMenu(); }, true);
  document.addEventListener("mousedown", (e) => {
    if (menu.style.display === "block" && !e.composedPath().includes(host)) closeMenu();
  }, true);

  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const directUrl = () => (current && /^https?:/i.test(current.currentSrc || "") ? current.currentSrc : null);

  async function onClick(e) {
    e.preventDefault();
    e.stopPropagation();
    if (menu.style.display === "block") return closeMenu();
    const pageUrl = location.href;
    openMenu(`<button class="x" title="${T.close}">✕</button><div class="msg">⏳ ${T.finding}</div>`);
    const res = await loadFormats(pageUrl);
    if (!res || !res.ok) return showFailure(res, pageUrl);
    const info = res.info;
    const rows = info.options
      .map((o, i) => `<button class="opt" data-i="${i}"><span>${esc(o.label)}</span><small>${fmtSize(o.size)}</small></button>`)
      .join("");
    const du = directUrl();
    const direct = du ? `<button class="opt" data-direct="1"><span>${T.direct}</span></button>` : "";
    openMenu(
      `<button class="x" title="${T.close}">✕</button><h4>${esc(info.title)}</h4>` +
        `<div class="sub">${info.compat ? T.phone : T.nophone}</div>${rows}${direct}`
    );
    menu.querySelectorAll(".opt").forEach((b) => {
      b.onclick = async () => {
        let r;
        if (b.dataset.direct) r = await send({ type: "addDirect", url: du, referer: pageUrl });
        else {
          const o = info.options[Number(b.dataset.i)];
          r = await send({ type: "addMedia", url: pageUrl, referer: pageUrl, height: o.height, audio: o.audio, title: info.title });
        }
        if (r && r.ok) {
          openMenu(`<div class="msg ok">${T.added}</div>`);
          setTimeout(closeMenu, 1400);
        } else showFailure(r, pageUrl);
      };
    });
  }

  function showFailure(res, pageUrl) {
    const du = directUrl();
    const appDown = !res || res.error === "app";
    const msg = appDown ? T.noapp : esc(res.error || "error");
    const direct = du ? `<button class="opt" data-direct="1"><span>${T.direct}</span></button>` : "";
    openMenu(`<button class="x" title="${T.close}">✕</button><div class="msg bad">${msg}</div>${appDown ? "" : direct}<button class="opt" id="retry"><span>${T.retry}</span></button>`);
    const rt = menu.querySelector("#retry");
    if (rt) rt.onclick = () => { closeMenu(); btn.click(); };
    const d = menu.querySelector("[data-direct]");
    if (d) d.onclick = async () => {
      const r = await send({ type: "addDirect", url: du, referer: pageUrl });
      if (r && r.ok) { openMenu(`<div class="msg ok">${T.added}</div>`); setTimeout(closeMenu, 1400); }
    };
  }

  // drag the button anywhere over the video (position is remembered)
  let drag = null;
  let justDragged = false;
  btn.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    const r = btn.getBoundingClientRect();
    drag = { px: e.clientX, py: e.clientY, left: r.left, top: r.top, moved: false };
    try { btn.setPointerCapture(e.pointerId); } catch (_) {}
  });
  btn.addEventListener("pointermove", (e) => {
    if (!drag) return;
    const dx = e.clientX - drag.px, dy = e.clientY - drag.py;
    if (!drag.moved && Math.hypot(dx, dy) < 5) return;
    if (!drag.moved) { drag.moved = true; dragging = true; if (menu.style.display === "block") closeMenu(); }
    const r = btn.getBoundingClientRect();
    btn.style.left = Math.max(0, Math.min(innerWidth - r.width, drag.left + dx)) + "px";
    btn.style.top = Math.max(0, Math.min(innerHeight - r.height, drag.top + dy)) + "px";
    clearTimeout(hideTimer);
  });
  const endDrag = (e) => {
    if (!drag) return;
    const moved = drag.moved;
    drag = null;
    try { btn.releasePointerCapture(e.pointerId); } catch (_) {}
    if (moved) {
      justDragged = true;
      setTimeout(() => { justDragged = false; }, 0);
      const b = btn.getBoundingClientRect();
      const v = current || bigVideos()[0];
      if (v) {
        const vr = v.getBoundingClientRect();
        off = { x: Math.round(b.left - vr.right), y: Math.round(b.top - vr.top) };
        try { chrome.storage.local.set({ btnOff: off }); } catch (_) {}
      }
      dragging = false;
      scheduleHide();
    }
  };
  btn.addEventListener("pointerup", endDrag);
  btn.addEventListener("pointercancel", endDrag);
  btn.addEventListener("click", (e) => {
    if (justDragged) { e.preventDefault(); e.stopPropagation(); return; }
    onClick(e);
  });
  document.documentElement.appendChild(host);
})();
