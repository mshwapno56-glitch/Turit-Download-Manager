//! Tiny local HTTP endpoint (127.0.0.1) used by the browser extension.
//!  GET  /ping  -> {"app":"turit","ok":true}
//!  POST /add   -> {"url","referer","cookie","userAgent","filename"}
//!  POST /formats   -> qualities of a video page (yt-dlp)
//!  POST /add-media -> {"url",...,"height","audio","title"}
//! Only browser-extension origins may POST (web pages cannot forge `Origin`).

use crate::{Manager, MediaSpec, ReqHeaders};
use serde::Deserialize;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};

#[derive(Deserialize)]
struct AddReq {
    url: String,
    referer: Option<String>,
    cookie: Option<String>,
    #[serde(rename = "userAgent")]
    user_agent: Option<String>,
    filename: Option<String>,
}

#[derive(Deserialize)]
struct MediaReq {
    url: String,
    referer: Option<String>,
    cookie: Option<String>,
    #[serde(rename = "userAgent")]
    user_agent: Option<String>,
    height: Option<u32>,
    #[serde(default)]
    audio: bool,
    title: Option<String>,
}

pub async fn serve(manager: Manager, port: u16) -> std::io::Result<()> {
    let listener = TcpListener::bind(("127.0.0.1", port)).await?;
    loop {
        let (sock, _) = listener.accept().await?;
        let m = manager.clone();
        tokio::spawn(async move {
            let _ = tokio::time::timeout(std::time::Duration::from_secs(120), handle(sock, m, port)).await;
        });
    }
}

fn find(hay: &[u8], needle: &[u8]) -> Option<usize> {
    hay.windows(needle.len()).position(|w| w == needle)
}

async fn handle(mut sock: TcpStream, m: Manager, port: u16) -> std::io::Result<()> {
    let mut data: Vec<u8> = Vec::new();
    let mut tmp = [0u8; 4096];
    let head_end = loop {
        if let Some(p) = find(&data, b"\r\n\r\n") {
            break p;
        }
        if data.len() > 64 * 1024 {
            return Ok(());
        }
        let n = sock.read(&mut tmp).await?;
        if n == 0 {
            return Ok(());
        }
        data.extend_from_slice(&tmp[..n]);
    };
    let head = String::from_utf8_lossy(&data[..head_end]).to_string();
    let mut lines = head.lines();
    let first = lines.next().unwrap_or("");
    let mut parts = first.split_whitespace();
    let method = parts.next().unwrap_or("").to_string();
    let path = parts.next().unwrap_or("").to_string();

    let mut origin = String::new();
    let mut host = String::new();
    let mut clen = 0usize;
    for l in lines {
        if let Some((k, v)) = l.split_once(':') {
            match k.trim().to_ascii_lowercase().as_str() {
                "origin" => origin = v.trim().to_string(),
                "host" => host = v.trim().to_ascii_lowercase(),
                "content-length" => clen = v.trim().parse().unwrap_or(0),
                _ => {}
            }
        }
    }

    // DNS-rebinding guard
    let host_ok = host == format!("127.0.0.1:{port}") || host == format!("localhost:{port}");
    let origin_ok = origin.starts_with("chrome-extension://") || origin.starts_with("moz-extension://");
    if !host_ok {
        return reply(&mut sock, 403, "", "{\"ok\":false}").await;
    }
    let cors = if origin_ok { origin.clone() } else { String::new() };

    if method == "OPTIONS" {
        return reply(&mut sock, 204, &cors, "").await;
    }
    if method == "GET" && path == "/ping" {
        return reply(&mut sock, 200, &cors, "{\"app\":\"turit\",\"ok\":true}").await;
    }
    if method == "POST" && (path == "/add" || path == "/formats" || path == "/add-media") {
        if !origin_ok || clen == 0 || clen > 64 * 1024 {
            return reply(&mut sock, 403, "", "{\"ok\":false}").await;
        }
        let mut body = data[head_end + 4..].to_vec();
        while body.len() < clen {
            let n = sock.read(&mut tmp).await?;
            if n == 0 {
                break;
            }
            body.extend_from_slice(&tmp[..n]);
        }
        let out: (u16, String) = if path == "/add" {
            match serde_json::from_slice::<AddReq>(&body) {
                Ok(r) => {
                    let h = ReqHeaders { referer: r.referer, cookie: r.cookie, user_agent: r.user_agent };
                    match m.add(r.url, h, None, r.filename) {
                        Ok(id) => (200, format!("{{\"ok\":true,\"id\":{id}}}")),
                        Err(e) => (400, serde_json::json!({"ok": false, "error": e}).to_string()),
                    }
                }
                Err(_) => (400, "{\"ok\":false}".to_string()),
            }
        } else {
            match serde_json::from_slice::<MediaReq>(&body) {
                Ok(r) => {
                    let h = ReqHeaders { referer: r.referer, cookie: r.cookie, user_agent: r.user_agent };
                    if path == "/formats" {
                        match m.media_info(&r.url, &h).await {
                            Ok(info) => (200, serde_json::json!({"ok": true, "info": info}).to_string()),
                            Err(e) => (400, serde_json::json!({"ok": false, "error": e}).to_string()),
                        }
                    } else {
                        let spec = MediaSpec { height: r.height, audio: r.audio };
                        match m.add_media(r.url, h, None, spec, r.title) {
                            Ok(id) => (200, format!("{{\"ok\":true,\"id\":{id}}}")),
                            Err(e) => (400, serde_json::json!({"ok": false, "error": e}).to_string()),
                        }
                    }
                }
                Err(_) => (400, "{\"ok\":false}".to_string()),
            }
        };
        return reply(&mut sock, out.0, &cors, &out.1).await;
    }
    reply(&mut sock, 404, &cors, "{\"ok\":false}").await
}

async fn reply(sock: &mut TcpStream, code: u16, cors_origin: &str, body: &str) -> std::io::Result<()> {
    let text = match code {
        200 => "OK",
        204 => "No Content",
        400 => "Bad Request",
        403 => "Forbidden",
        _ => "Not Found",
    };
    let mut h = format!(
        "HTTP/1.1 {code} {text}\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n",
        body.len()
    );
    if !cors_origin.is_empty() {
        h.push_str(&format!(
            "Access-Control-Allow-Origin: {cors_origin}\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type\r\nAccess-Control-Allow-Private-Network: true\r\nVary: Origin\r\n"
        ));
    }
    h.push_str("\r\n");
    sock.write_all(h.as_bytes()).await?;
    sock.write_all(body.as_bytes()).await?;
    sock.shutdown().await
}
