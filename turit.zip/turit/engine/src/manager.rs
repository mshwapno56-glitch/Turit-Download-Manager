use crate::model::*;
use crate::media;
use crate::probe::{self, apply_headers};
use futures_util::StreamExt;
use std::collections::HashMap;
use std::io::SeekFrom;
use std::path::{Path, PathBuf};
use std::process::Stdio;
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicU8, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use tokio::io::{AsyncBufReadExt, AsyncSeekExt, AsyncWriteExt, BufReader};
use tokio::runtime::Handle;
use tokio::task::JoinSet;

const SC: Ordering = Ordering::SeqCst;
const FLUSH_BYTES: usize = 512 * 1024;
const MAX_FAILS: u32 = 12;
const STALL_SECS: u64 = 30;

// ---------------------------------------------------------------- state

struct State {
    next_id: u64,
    settings: Settings,
    items: Vec<Item>,
}

/// Runtime handle of one active download.
struct Running {
    /// 0 = run, 1 = paused by user, 2 = removed, 3 = stopped by error
    cancel: AtomicU8,
    counters: Mutex<Option<Arc<Vec<AtomicU64>>>>,
    last_sum: AtomicU64,
}

impl Running {
    fn stopped(&self) -> bool {
        self.cancel.load(SC) != 0
    }
}

struct Inner {
    rt: Handle,
    client: reqwest::Client,
    path: PathBuf,
    state: Mutex<State>,
    running: Mutex<HashMap<u64, Arc<Running>>>,
    tools: Mutex<Vec<PathBuf>>,
}

#[derive(Clone)]
pub struct Manager {
    inner: Arc<Inner>,
}

enum Outcome {
    Completed,
    Stopped,
}

fn now_secs() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

// ---------------------------------------------------------------- public API

impl Manager {
    /// Must be called from inside a tokio runtime.
    pub fn new(state_path: PathBuf, default_dir: String) -> Manager {
        let client = reqwest::Client::builder()
            .connect_timeout(Duration::from_secs(20))
            .pool_idle_timeout(Duration::from_secs(30))
            .build()
            .expect("http client");

        let mut state = State {
            next_id: 1,
            settings: Settings { dir: default_dir.clone(), connections: 8, max_active: 3 },
            items: vec![],
        };
        if let Ok(txt) = std::fs::read_to_string(&state_path) {
            if let Ok(p) = serde_json::from_str::<Persist>(&txt) {
                state.next_id = p.next_id.max(1);
                state.settings = p.settings.clamped();
                if state.settings.dir.is_empty() {
                    state.settings.dir = default_dir;
                }
                state.items = p.items;
                for it in state.items.iter_mut() {
                    it.speed = 0;
                    if matches!(it.status, Status::Downloading | Status::Queued) {
                        it.status = Status::Paused;
                    }
                }
            }
        }

        let inner = Arc::new(Inner {
            rt: Handle::current(),
            client,
            path: state_path,
            state: Mutex::new(state),
            running: Mutex::new(HashMap::new()),
            tools: Mutex::new(vec![]),
        });
        inner.rt.spawn(ticker(inner.clone()));
        Manager { inner }
    }

    pub fn add(
        &self,
        url: String,
        headers: ReqHeaders,
        dir: Option<String>,
        filename: Option<String>,
    ) -> Result<u64, String> {
        let url = url.trim().to_string();
        let parsed = reqwest::Url::parse(&url).map_err(|_| "Invalid URL".to_string())?;
        if parsed.scheme() != "http" && parsed.scheme() != "https" {
            return Err("Only http/https links are supported".into());
        }
        if filename.is_none() && parsed.host_str().map(is_media_host).unwrap_or(false) {
            // YouTube & co: a page link, not a file -> let yt-dlp handle it
            return self.add_media(url, headers, dir, MediaSpec { height: None, audio: false }, None);
        }
        let filename = filename.map(|f| f.trim().to_string()).filter(|f| !f.is_empty());
        let name_locked = filename.is_some();
        let fname = filename.map(|f| probe::sanitize(&f)).unwrap_or_else(|| probe::name_from_url(&parsed));
        let id;
        {
            let mut st = self.inner.state.lock().unwrap();
            id = st.next_id;
            st.next_id += 1;
            let dir = dir.filter(|d| !d.trim().is_empty()).unwrap_or_else(|| st.settings.dir.clone());
            st.items.push(Item {
                id,
                url,
                filename: fname,
                dir,
                name_locked,
                total: None,
                resumable: false,
                status: Status::Queued,
                segments: vec![],
                downloaded: 0,
                speed: 0,
                error: None,
                added: now_secs(),
                headers,
                media: None,
            });
        }
        self.inner.save();
        self.inner.schedule();
        Ok(id)
    }

    /// Video from a page (YouTube etc.) through yt-dlp, in the chosen quality.
    pub fn add_media(
        &self,
        url: String,
        headers: ReqHeaders,
        dir: Option<String>,
        spec: MediaSpec,
        title: Option<String>,
    ) -> Result<u64, String> {
        let url = url.trim().to_string();
        let parsed = reqwest::Url::parse(&url).map_err(|_| "Invalid URL".to_string())?;
        if parsed.scheme() != "http" && parsed.scheme() != "https" {
            return Err("Only http/https links are supported".into());
        }
        let title = title.map(|t| t.trim().to_string()).filter(|t| !t.is_empty());
        let name_locked = title.is_some();
        let filename = match &title {
            Some(t) => media_filename(t, &spec),
            None => "video.mp4".to_string(),
        };
        let id;
        {
            let mut st = self.inner.state.lock().unwrap();
            id = st.next_id;
            st.next_id += 1;
            let dir = dir.filter(|d| !d.trim().is_empty()).unwrap_or_else(|| st.settings.dir.clone());
            st.items.push(Item {
                id,
                url,
                filename,
                dir,
                name_locked,
                total: None,
                resumable: true,
                status: Status::Queued,
                segments: vec![],
                downloaded: 0,
                speed: 0,
                error: None,
                added: now_secs(),
                headers,
                media: Some(spec),
            });
        }
        self.inner.save();
        self.inner.schedule();
        Ok(id)
    }

    /// Which qualities does this page offer? (runs yt-dlp)
    pub async fn media_info(&self, url: &str, headers: &ReqHeaders) -> Result<media::MediaInfo, String> {
        let ytdlp = self.inner.tool("yt-dlp");
        let extra = self.inner.runtime_args();
        media::probe(&ytdlp, url, headers, &extra).await
    }

    /// Folders searched for yt-dlp / ffmpeg.
    pub fn set_tools_dirs(&self, dirs: Vec<PathBuf>) {
        *self.inner.tools.lock().unwrap() = dirs;
    }

    /// Keep yt-dlp current (video sites change often). Runs in the background.
    pub fn update_ytdlp(&self) {
        let ytdlp = self.inner.tool("yt-dlp");
        self.inner.rt.spawn(async move {
            let mut c = media::command(&ytdlp);
            c.arg("-U").stdout(Stdio::null()).stderr(Stdio::null());
            let _ = tokio::time::timeout(Duration::from_secs(120), c.status()).await;
        });
    }

    pub fn list(&self) -> Vec<View> {
        let st = self.inner.state.lock().unwrap();
        st.items.iter().rev().map(View::from).collect()
    }

    pub fn pause(&self, id: u64) {
        {
            let mut st = self.inner.state.lock().unwrap();
            if let Some(it) = st.items.iter_mut().find(|i| i.id == id) {
                if matches!(it.status, Status::Downloading | Status::Queued) {
                    it.status = Status::Paused;
                    it.speed = 0;
                }
            }
        }
        if let Some(r) = self.inner.running.lock().unwrap().get(&id) {
            r.cancel.store(1, SC);
        }
        self.inner.save();
        self.inner.schedule();
    }

    pub fn resume(&self, id: u64) {
        {
            let mut st = self.inner.state.lock().unwrap();
            if let Some(it) = st.items.iter_mut().find(|i| i.id == id) {
                if matches!(it.status, Status::Paused | Status::Error) {
                    it.status = Status::Queued;
                    it.error = None;
                    if !it.resumable {
                        for s in it.segments.iter_mut() {
                            s.done = 0;
                        }
                        it.downloaded = 0;
                    }
                }
            }
        }
        self.inner.save();
        self.inner.schedule();
    }

    pub fn pause_all(&self) {
        let ids: Vec<u64> = self.inner.state.lock().unwrap().items.iter().map(|i| i.id).collect();
        for id in ids {
            self.pause(id);
        }
    }

    pub fn resume_all(&self) {
        let ids: Vec<u64> = self.inner.state.lock().unwrap().items.iter().map(|i| i.id).collect();
        for id in ids {
            self.resume(id);
        }
    }

    pub fn remove(&self, id: u64, delete_file: bool) {
        let item = {
            let mut st = self.inner.state.lock().unwrap();
            let pos = st.items.iter().position(|i| i.id == id);
            match pos {
                Some(p) => Some(st.items.remove(p)),
                None => None,
            }
        };
        let Some(item) = item else { return };
        if let Some(r) = self.inner.running.lock().unwrap().get(&id) {
            r.cancel.store(2, SC);
        }
        self.inner.save();
        self.inner.schedule();
        let inner = self.inner.clone();
        self.inner.rt.spawn(async move {
            // wait for workers to let go of the file
            for _ in 0..50 {
                if !inner.running.lock().unwrap().contains_key(&id) {
                    break;
                }
                tokio::time::sleep(Duration::from_millis(200)).await;
            }
            let fin = PathBuf::from(&item.dir).join(&item.filename);
            let part = PathBuf::from(&item.dir).join(format!("{}.part", item.filename));
            if item.status != Status::Completed {
                let _ = tokio::fs::remove_file(&part).await;
                if item.media.is_some() {
                    cleanup_media(&PathBuf::from(&item.dir), &item.filename);
                }
            } else if delete_file {
                let _ = tokio::fs::remove_file(&fin).await;
            }
        });
    }

    pub fn settings(&self) -> Settings {
        self.inner.state.lock().unwrap().settings.clone()
    }

    pub fn set_settings(&self, s: Settings) {
        {
            let mut st = self.inner.state.lock().unwrap();
            let mut s = s.clamped();
            if s.dir.trim().is_empty() {
                s.dir = st.settings.dir.clone();
            }
            st.settings = s;
        }
        self.inner.save();
        self.inner.schedule();
    }

    /// Final file path of a download (the file may not exist yet).
    pub fn final_path(&self, id: u64) -> Option<PathBuf> {
        let st = self.inner.state.lock().unwrap();
        st.items.iter().find(|i| i.id == id).map(|i| PathBuf::from(&i.dir).join(&i.filename))
    }
}

// ---------------------------------------------------------------- inner helpers

impl Inner {
    fn save(&self) {
        let json = {
            let st = self.state.lock().unwrap();
            let value = serde_json::json!({
                "next_id": st.next_id,
                "settings": &st.settings,
                "items": &st.items,
            });
            drop(st);
            serde_json::to_string(&value)
        };
        if let Ok(j) = json {
            let tmp = self.path.with_extension("tmp");
            if std::fs::write(&tmp, j).is_ok() {
                let _ = std::fs::rename(&tmp, &self.path);
            }
        }
    }

    fn tool(&self, name: &str) -> PathBuf {
        media::tool_path(&self.tools.lock().unwrap(), name)
    }

    /// `--js-runtimes deno:<path>` when deno.exe is installed with the app.
    fn runtime_args(&self) -> Vec<String> {
        let p = self.tool("deno");
        if p.is_file() {
            media::runtime_args(Some(p.as_path()))
        } else {
            vec![]
        }
    }

    fn tool_dir(&self, name: &str) -> Option<PathBuf> {
        let p = self.tool(name);
        if p.is_file() {
            p.parent().map(|d| d.to_path_buf())
        } else {
            None
        }
    }

    fn update<R>(&self, id: u64, f: impl FnOnce(&mut Item) -> R) -> Option<R> {
        let mut st = self.state.lock().unwrap();
        st.items.iter_mut().find(|i| i.id == id).map(f)
    }

    fn get(&self, id: u64) -> Option<Item> {
        self.state.lock().unwrap().items.iter().find(|i| i.id == id).cloned()
    }

    /// Start queued downloads while there is a free slot.
    fn schedule(self: &Arc<Self>) {
        let mut to_start: Vec<(u64, Arc<Running>)> = vec![];
        {
            let mut st = self.state.lock().unwrap();
            let mut running = self.running.lock().unwrap();
            let max = st.settings.max_active.max(1) as usize;
            let mut active = st.items.iter().filter(|i| i.status == Status::Downloading).count();
            for it in st.items.iter_mut() {
                if active >= max {
                    break;
                }
                if it.status == Status::Queued && !running.contains_key(&it.id) {
                    it.status = Status::Downloading;
                    it.error = None;
                    active += 1;
                    let r = Arc::new(Running {
                        cancel: AtomicU8::new(0),
                        counters: Mutex::new(None),
                        last_sum: AtomicU64::new(it.downloaded),
                    });
                    running.insert(it.id, r.clone());
                    to_start.push((it.id, r));
                }
            }
        }
        for (id, run) in to_start {
            let inner = self.clone();
            self.rt.spawn(run_item(inner, id, run));
        }
    }

    /// Copy live byte counters into the stored item.
    fn sync(&self, id: u64, run: &Running) {
        let c = run.counters.lock().unwrap().clone();
        if let Some(c) = c {
            self.update(id, |it| {
                let mut sum = 0;
                for (i, s) in it.segments.iter_mut().enumerate() {
                    if let Some(a) = c.get(i) {
                        s.done = a.load(SC);
                    }
                    sum += s.done;
                }
                it.downloaded = sum;
            });
        }
    }
}

async fn ticker(inner: Arc<Inner>) {
    let mut last = Instant::now();
    let mut tick = 0u32;
    loop {
        tokio::time::sleep(Duration::from_millis(500)).await;
        let dt = last.elapsed().as_secs_f64().max(0.05);
        last = Instant::now();
        let runs: Vec<(u64, Arc<Running>)> =
            inner.running.lock().unwrap().iter().map(|(k, v)| (*k, v.clone())).collect();
        for (id, run) in &runs {
            inner.sync(*id, run);
        }
        {
            let mut st = inner.state.lock().unwrap();
            for it in st.items.iter_mut() {
                let run = runs.iter().find(|(id, _)| *id == it.id).map(|(_, r)| r);
                match run {
                    Some(r) if it.status == Status::Downloading => {
                        let prev = r.last_sum.swap(it.downloaded, SC);
                        let inst = it.downloaded.saturating_sub(prev) as f64 / dt;
                        it.speed = if it.speed == 0 { inst as u64 } else { (it.speed as f64 * 0.6 + inst * 0.4) as u64 };
                    }
                    _ => it.speed = 0,
                }
            }
        }
        tick += 1;
        if tick % 4 == 0 && !runs.is_empty() {
            inner.save();
        }
    }
}

// ---------------------------------------------------------------- one download

async fn run_item(inner: Arc<Inner>, id: u64, run: Arc<Running>) {
    let res = download(&inner, id, &run).await;
    inner.sync(id, &run);
    match res {
        Ok(Outcome::Completed) => {
            inner.update(id, |it| {
                it.status = Status::Completed;
                it.speed = 0;
                it.error = None;
                if let Some(t) = it.total {
                    it.downloaded = t;
                }
            });
        }
        Ok(Outcome::Stopped) => {}
        Err(e) => {
            let c = run.cancel.load(SC);
            if c != 1 && c != 2 {
                inner.update(id, |it| {
                    if it.status == Status::Downloading {
                        it.status = Status::Error;
                        it.error = Some(e);
                        it.speed = 0;
                    }
                });
            }
        }
    }
    inner.running.lock().unwrap().remove(&id);
    inner.save();
    inner.schedule();
}

fn plan(total: Option<u64>, resumable: bool, conns: u32) -> Vec<Segment> {
    match total {
        Some(t) if t > 0 && resumable => {
            let c = conns.max(1) as u64;
            let seg = (t / (c * 4)).clamp(1 << 20, 64 << 20);
            let mut v = vec![];
            let mut s = 0u64;
            while s < t {
                let e = (s + seg - 1).min(t - 1);
                v.push(Segment { start: s, end: e, done: 0 });
                s = e + 1;
            }
            v
        }
        Some(t) if t > 0 => vec![Segment { start: 0, end: t - 1, done: 0 }],
        Some(_) => vec![],
        None => vec![Segment { start: 0, end: u64::MAX, done: 0 }],
    }
}

fn unique_name(st: &State, id: u64, dir: &str, name: &str) -> String {
    let taken = |n: &str| {
        let p = PathBuf::from(dir).join(n);
        p.exists()
            || PathBuf::from(dir).join(format!("{n}.part")).exists()
            || st.items.iter().any(|i| i.id != id && i.dir == dir && i.filename == n)
    };
    if !taken(name) {
        return name.to_string();
    }
    let (stem, ext) = match name.rsplit_once('.') {
        Some((s, e)) if !s.is_empty() => (s.to_string(), format!(".{e}")),
        _ => (name.to_string(), String::new()),
    };
    for n in 1..10000 {
        let cand = format!("{stem} ({n}){ext}");
        if !taken(&cand) {
            return cand;
        }
    }
    name.to_string()
}

async fn download(inner: &Arc<Inner>, id: u64, run: &Arc<Running>) -> Result<Outcome, String> {
    let mut item = inner.get(id).ok_or("download not found")?;
    if item.media.is_some() {
        return run_media(inner, id, run).await;
    }
    let conns = inner.state.lock().unwrap().settings.connections.max(1);

    // 1. first start: ask the server about size / ranges / file name
    if item.segments.is_empty() && item.total != Some(0) {
        let p = probe::probe(&inner.client, &item.url, &item.headers).await?;
        if run.stopped() {
            return Ok(Outcome::Stopped);
        }
        {
            let mut st = inner.state.lock().unwrap();
            let name = if item.name_locked { item.filename.clone() } else { p.filename.clone() };
            let name = unique_name(&st, id, &item.dir, &name);
            if let Some(it) = st.items.iter_mut().find(|i| i.id == id) {
                it.total = p.total;
                it.resumable = p.resumable;
                it.filename = name;
                it.segments = plan(p.total, p.resumable, conns);
                it.downloaded = 0;
            }
        }
        inner.save();
        item = inner.get(id).ok_or("download not found")?;
    }

    let dir = PathBuf::from(&item.dir);
    tokio::fs::create_dir_all(&dir).await.map_err(|e| format!("folder: {e}"))?;
    let fin = dir.join(&item.filename);
    let part = dir.join(format!("{}.part", item.filename));

    // empty file
    if item.total == Some(0) {
        tokio::fs::write(&fin, b"").await.map_err(|e| format!("file: {e}"))?;
        return Ok(Outcome::Completed);
    }

    // 2. sanity: progress recorded but the partial file is gone -> start over
    let part_exists = tokio::fs::metadata(&part).await.is_ok();
    let any_done = item.segments.iter().any(|s| s.done > 0);
    let restart = !item.resumable || (any_done && !part_exists);
    if restart {
        for s in item.segments.iter_mut() {
            s.done = 0;
        }
    }

    let f = tokio::fs::OpenOptions::new()
        .create(true)
        .write(true)
        .truncate(restart)
        .open(&part)
        .await
        .map_err(|e| format!("file: {e}"))?;
    if let (Some(t), true) = (item.total, item.resumable) {
        let len = f.metadata().await.map(|m| m.len()).unwrap_or(0);
        if len != t {
            f.set_len(t).await.map_err(|e| format!("disk: {e}"))?;
        }
    }
    drop(f);

    // 3. live counters
    let counters: Arc<Vec<AtomicU64>> = Arc::new(item.segments.iter().map(|s| AtomicU64::new(s.done)).collect());
    inner.update(id, |it| {
        for s in it.segments.iter_mut() {
            if restart {
                s.done = 0;
            }
        }
    });
    run.last_sum.store(item.segments.iter().map(|s| s.done).sum(), SC);
    *run.counters.lock().unwrap() = Some(counters.clone());

    let segs: Vec<(u64, u64)> = item.segments.iter().map(|s| (s.start, s.end)).collect();
    let pending = segs
        .iter()
        .enumerate()
        .filter(|(i, (s, e))| *e == u64::MAX || counters[*i].load(SC) <= *e - *s)
        .count();
    let ctx = Arc::new(Ctx {
        client: inner.client.clone(),
        url: item.url.clone(),
        headers: item.headers.clone(),
        part: part.clone(),
        segs,
        counters,
        next: AtomicUsize::new(0),
        ranged: item.resumable,
        run: run.clone(),
        unknown_done: AtomicBool::new(false),
    });

    // 4. workers pull segments from a shared queue
    let workers = (conns as usize).min(pending).max(1);
    let mut set = JoinSet::new();
    for _ in 0..workers {
        set.spawn(worker(ctx.clone()));
    }
    let mut first_err: Option<String> = None;
    while let Some(r) = set.join_next().await {
        let err = match r {
            Ok(Ok(())) => None,
            Ok(Err(e)) => Some(e),
            Err(e) => Some(e.to_string()),
        };
        if let Some(e) = err {
            if first_err.is_none() {
                first_err = Some(e);
            }
            let _ = run.cancel.compare_exchange(0, 3, SC, SC);
        }
    }
    inner.sync(id, run);

    let c = run.cancel.load(SC);
    if c == 1 || c == 2 {
        return Ok(Outcome::Stopped);
    }
    if let Some(e) = first_err {
        return Err(e);
    }

    // 5. finish
    let unknown = ctx.segs.first().map(|s| s.1 == u64::MAX).unwrap_or(false);
    if unknown {
        if !ctx.unknown_done.load(SC) {
            return Err("download did not finish".into());
        }
        let n = ctx.counters[0].load(SC);
        inner.update(id, |it| it.total = Some(n));
    } else {
        for (i, (s, e)) in ctx.segs.iter().enumerate() {
            if ctx.counters[i].load(SC) < e - s + 1 {
                return Err("download incomplete".into());
            }
        }
    }
    let _ = tokio::fs::remove_file(&fin).await;
    tokio::fs::rename(&part, &fin).await.map_err(|e| format!("rename: {e}"))?;
    Ok(Outcome::Completed)
}

// ---------------------------------------------------------------- video sites

fn is_media_host(h: &str) -> bool {
    let h = h.to_ascii_lowercase();
    const SITES: [&str; 12] = [
        "youtube.com", "youtu.be", "facebook.com", "fb.watch", "instagram.com", "tiktok.com", "twitter.com",
        "x.com", "vimeo.com", "dailymotion.com", "twitch.tv", "reddit.com",
    ];
    SITES.iter().any(|d| h == *d || h.ends_with(&format!(".{d}")))
}

fn media_filename(title: &str, spec: &MediaSpec) -> String {
    let t = probe::sanitize(title);
    if spec.audio {
        format!("{t}.m4a")
    } else if let Some(h) = spec.height {
        format!("{t} [{h}p].mp4")
    } else {
        format!("{t}.mp4")
    }
}

/// Delete leftovers of an unfinished yt-dlp download.
fn cleanup_media(dir: &Path, filename: &str) {
    let stem = Path::new(filename).file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
    if stem.is_empty() {
        return;
    }
    if let Ok(rd) = std::fs::read_dir(dir) {
        for e in rd.flatten() {
            let n = e.file_name().to_string_lossy().to_string();
            if n.starts_with(&format!("{stem}.")) && (n.ends_with(".part") || n.ends_with(".ytdl")) {
                let _ = std::fs::remove_file(e.path());
            }
        }
    }
}

/// Find the finished file yt-dlp wrote for `stem`.
fn find_output(dir: &Path, stem: &str) -> Option<String> {
    for ext in ["mp4", "m4a", "mkv", "webm", "mp3"] {
        let n = format!("{stem}.{ext}");
        if dir.join(&n).is_file() {
            return Some(n);
        }
    }
    let rd = std::fs::read_dir(dir).ok()?;
    for e in rd.flatten() {
        let n = e.file_name().to_string_lossy().to_string();
        if n.starts_with(&format!("{stem}.")) && !n.ends_with(".part") && !n.ends_with(".ytdl") {
            return Some(n);
        }
    }
    None
}

async fn run_media(inner: &Arc<Inner>, id: u64, run: &Arc<Running>) -> Result<Outcome, String> {
    let mut item = inner.get(id).ok_or("download not found")?;
    let spec = item.media.clone().ok_or("not a video item")?;
    let ytdlp = inner.tool("yt-dlp");
    let conns = inner.state.lock().unwrap().settings.connections.clamp(1, 16);
    let dir = PathBuf::from(&item.dir);
    tokio::fs::create_dir_all(&dir).await.map_err(|e| format!("folder: {e}"))?;

    // 1. title + size estimate (only when the browser did not already tell us)
    if !item.name_locked {
        let extra = inner.runtime_args();
        let info = media::probe(&ytdlp, &item.url, &item.headers, &extra).await?;
        if run.stopped() {
            return Ok(Outcome::Stopped);
        }
        let size = info
            .options
            .iter()
            .find(|o| o.audio == spec.audio && (spec.audio || spec.height.is_none() || o.height == spec.height))
            .and_then(|o| o.size);
        let name = media_filename(&info.title, &spec);
        inner.update(id, |it| {
            it.filename = name;
            it.name_locked = true;
            it.total = size;
        });
    }
    // never overwrite an older file with the same name
    let name = {
        let cur = inner.get(id).ok_or("download not found")?;
        let st = inner.state.lock().unwrap();
        unique_name(&st, id, &cur.dir, &cur.filename)
    };
    inner.update(id, |it| it.filename = name);
    item = inner.get(id).ok_or("download not found")?;

    let stem = Path::new(&item.filename)
        .file_stem()
        .map(|s| s.to_string_lossy().to_string())
        .unwrap_or_else(|| "video".to_string());
    let base = dir.join(&stem).to_string_lossy().replace('%', "%%");
    let out_tpl = format!("{base}.%(ext)s");
    let nstr = conns.to_string();

    let mut cmd = media::command(&ytdlp);
    cmd.args([
        "--newline",
        "--no-warnings",
        "--no-playlist",
        "--no-mtime",
        "--windows-filenames",
        "--encoding",
        "utf-8",
        "--progress-template",
        "download:PROG %(progress.downloaded_bytes)s %(progress.total_bytes)s %(progress.total_bytes_estimate)s",
        "-N",
        nstr.as_str(),
    ]);
    cmd.args(inner.runtime_args());
    cmd.args(media::format_args(spec.height, spec.audio));
    cmd.arg("-o").arg(&out_tpl);
    if let Some(ff) = inner.tool_dir("ffmpeg") {
        cmd.arg("--ffmpeg-location").arg(ff);
    }
    cmd.args(media::header_args(&item.headers));
    cmd.arg(&item.url);
    cmd.stdout(Stdio::piped()).stderr(Stdio::piped());

    let mut child = cmd.spawn().map_err(|e| format!("yt-dlp not found: {e}"))?;
    let stdout = child.stdout.take().ok_or("no output from yt-dlp")?;
    let stderr = child.stderr.take().ok_or("no output from yt-dlp")?;
    let last_err = Arc::new(Mutex::new(String::new()));
    {
        let le = last_err.clone();
        tokio::spawn(async move {
            let mut l = BufReader::new(stderr).lines();
            while let Ok(Some(line)) = l.next_line().await {
                if !line.trim().is_empty() {
                    *le.lock().unwrap() = line;
                }
            }
        });
    }

    // 2. follow progress lines; kill the process when paused / removed
    let mut lines = BufReader::new(stdout).lines();
    let mut base_bytes = 0u64; // video and audio are separate files: add them up
    let mut last_cur = 0u64;
    loop {
        if run.stopped() {
            let _ = child.kill().await;
            return Ok(Outcome::Stopped);
        }
        tokio::select! {
            line = lines.next_line() => match line {
                Ok(Some(l)) => {
                    if let Some(rest) = l.strip_prefix("PROG ") {
                        let p: Vec<&str> = rest.split_whitespace().collect();
                        let cur = p.first().and_then(|s| s.parse::<f64>().ok()).map(|x| x as u64);
                        if let Some(cur) = cur {
                            if cur < last_cur {
                                base_bytes += last_cur;
                            }
                            last_cur = cur;
                            let now = base_bytes + cur;
                            inner.update(id, |it| {
                                it.downloaded = now;
                                if let Some(t) = it.total {
                                    if now > t {
                                        it.total = Some(now);
                                    }
                                }
                            });
                        }
                    }
                }
                _ => break,
            },
            _ = tokio::time::sleep(Duration::from_millis(300)) => {}
        }
    }
    let status = child.wait().await.map_err(|e| e.to_string())?;
    let c = run.cancel.load(SC);
    if c == 1 || c == 2 {
        return Ok(Outcome::Stopped);
    }
    if !status.success() {
        let msg = last_err.lock().unwrap().clone();
        return Err(if msg.is_empty() { format!("yt-dlp failed ({status})") } else { msg });
    }

    // 3. finished: pick up the real file name and size
    let found = find_output(&dir, &stem).ok_or("finished file not found")?;
    let size = std::fs::metadata(dir.join(&found)).map(|m| m.len()).ok();
    inner.update(id, |it| {
        it.filename = found;
        it.total = size;
        if let Some(s) = size {
            it.downloaded = s;
        }
    });
    Ok(Outcome::Completed)
}

// ---------------------------------------------------------------- workers

struct Ctx {
    client: reqwest::Client,
    url: String,
    headers: ReqHeaders,
    part: PathBuf,
    segs: Vec<(u64, u64)>,
    counters: Arc<Vec<AtomicU64>>,
    next: AtomicUsize,
    ranged: bool,
    run: Arc<Running>,
    unknown_done: AtomicBool,
}

async fn worker(ctx: Arc<Ctx>) -> Result<(), String> {
    let mut file = tokio::fs::OpenOptions::new()
        .write(true)
        .open(&ctx.part)
        .await
        .map_err(|e| format!("file: {e}"))?;
    loop {
        if ctx.run.stopped() {
            return Ok(());
        }
        let idx = ctx.next.fetch_add(1, SC);
        if idx >= ctx.segs.len() {
            return Ok(());
        }
        let (s, e) = ctx.segs[idx];
        if e != u64::MAX && ctx.counters[idx].load(SC) > e - s {
            continue; // already complete
        }
        segment(&ctx, &mut file, idx).await?;
    }
}

async fn sleep_unless_stopped(run: &Running, total: Duration) {
    let mut left = total;
    while left > Duration::ZERO && !run.stopped() {
        let step = left.min(Duration::from_millis(200));
        tokio::time::sleep(step).await;
        left -= step;
    }
}

async fn segment(ctx: &Ctx, file: &mut tokio::fs::File, idx: usize) -> Result<(), String> {
    let (start, end) = ctx.segs[idx];
    let len = if end == u64::MAX { None } else { Some(end - start + 1) };
    let counter = &ctx.counters[idx];
    let mut fails = 0u32;
    loop {
        if ctx.run.stopped() {
            return Ok(());
        }
        if let Some(l) = len {
            if counter.load(SC) >= l {
                return Ok(());
            }
        }
        let before = counter.load(SC);
        match attempt(ctx, file, idx, start, end, len).await {
            Ok(()) => return Ok(()),
            Err((true, m)) => return Err(m),
            Err((false, m)) => {
                if counter.load(SC) > before {
                    fails = 0;
                }
                fails += 1;
                if fails > MAX_FAILS {
                    return Err(m);
                }
                let wait = Duration::from_millis((400u64 << (fails - 1).min(5)).min(8000));
                sleep_unless_stopped(&ctx.run, wait).await;
            }
        }
    }
}

/// One HTTP request for (the rest of) one segment.
/// Err((fatal, message)): fatal errors are not retried.
async fn attempt(
    ctx: &Ctx,
    file: &mut tokio::fs::File,
    idx: usize,
    start: u64,
    end: u64,
    len: Option<u64>,
) -> Result<(), (bool, String)> {
    let counter = &ctx.counters[idx];
    if !ctx.ranged {
        counter.store(0, SC); // cannot resume a plain stream: start again
    }
    let done = counter.load(SC);

    let mut req = apply_headers(ctx.client.get(&ctx.url), &ctx.headers);
    if ctx.ranged {
        let from = start + done;
        let v = if len.is_some() { format!("bytes={from}-{end}") } else { format!("bytes={from}-") };
        req = req.header(reqwest::header::RANGE, v);
    }
    let resp = req.send().await.map_err(|e| (false, e.to_string()))?;
    let st = resp.status().as_u16();
    let ok = if ctx.ranged { st == 206 } else { (200..300).contains(&st) };
    if !ok {
        let retry = st == 429 || st == 408 || (500..600).contains(&st);
        let msg = if ctx.ranged && st == 200 {
            "server stopped supporting resume".to_string()
        } else {
            format!("HTTP {st}")
        };
        return Err((!retry, msg));
    }

    file.seek(SeekFrom::Start(start + done)).await.map_err(|e| (true, format!("file: {e}")))?;

    let mut stream = Box::pin(resp.bytes_stream());
    let mut buf: Vec<u8> = Vec::with_capacity(FLUSH_BYTES + 64 * 1024);
    let mut last_flush = Instant::now();
    let mut last_data = Instant::now();
    let mut remaining = len.map(|l| l - done);
    let mut stream_err: Option<String> = None;
    let mut ended = false;

    loop {
        if ctx.run.stopped() {
            break;
        }
        match tokio::time::timeout(Duration::from_millis(400), stream.next()).await {
            Err(_) => {
                if last_data.elapsed() > Duration::from_secs(STALL_SECS) {
                    stream_err = Some("connection stalled".into());
                    break;
                }
                if !buf.is_empty() {
                    flush(file, &mut buf, counter).await?;
                    last_flush = Instant::now();
                }
            }
            Ok(None) => {
                ended = true;
                break;
            }
            Ok(Some(Err(e))) => {
                stream_err = Some(e.to_string());
                break;
            }
            Ok(Some(Ok(mut c))) => {
                last_data = Instant::now();
                if let Some(r) = remaining {
                    if c.len() as u64 > r {
                        c.truncate(r as usize);
                    }
                    remaining = Some(r - c.len() as u64);
                }
                buf.extend_from_slice(&c);
                if buf.len() >= FLUSH_BYTES || last_flush.elapsed() > Duration::from_millis(300) {
                    flush(file, &mut buf, counter).await?;
                    last_flush = Instant::now();
                }
                if remaining == Some(0) {
                    ended = true;
                    break;
                }
            }
        }
    }
    flush(file, &mut buf, counter).await?;

    if ctx.run.stopped() {
        return Ok(());
    }
    if let Some(e) = stream_err {
        return Err((false, e));
    }
    match len {
        Some(l) => {
            if counter.load(SC) < l {
                return Err((false, "connection closed early".into()));
            }
        }
        None => {
            if ended {
                ctx.unknown_done.store(true, SC);
            }
        }
    }
    Ok(())
}

async fn flush(file: &mut tokio::fs::File, buf: &mut Vec<u8>, counter: &AtomicU64) -> Result<(), (bool, String)> {
    if buf.is_empty() {
        return Ok(());
    }
    file.write_all(buf).await.map_err(|e| (true, format!("disk: {e}")))?;
    file.flush().await.map_err(|e| (true, format!("disk: {e}")))?;
    counter.fetch_add(buf.len() as u64, SC);
    buf.clear();
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn plan_splits_cover_file() {
        let v = plan(Some(100 * 1024 * 1024 + 7), true, 8);
        assert_eq!(v.first().unwrap().start, 0);
        assert_eq!(v.last().unwrap().end, 100 * 1024 * 1024 + 6);
        for w in v.windows(2) {
            assert_eq!(w[0].end + 1, w[1].start);
        }
        assert_eq!(plan(Some(10), true, 8).len(), 1);
        assert_eq!(plan(Some(10), false, 8).len(), 1);
        assert!(plan(Some(0), true, 8).is_empty());
        assert_eq!(plan(None, false, 8)[0].end, u64::MAX);
    }
}
