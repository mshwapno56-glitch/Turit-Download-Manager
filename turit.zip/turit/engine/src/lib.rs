//! Turit download engine: multi-connection, resumable, queued downloads.

pub mod manager;
pub mod media;
pub mod model;
mod probe;
pub mod server;

pub use manager::Manager;
pub use media::{MediaInfo, MediaOption};
pub use model::{Event, Item, MediaSpec, ReqHeaders, Segment, Settings, Status, View};
