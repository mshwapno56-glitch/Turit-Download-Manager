use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Serialize, Deserialize, Clone, Copy, Debug, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum Status {
    Queued,
    Downloading,
    Paused,
    Completed,
    Error,
}

/// Extra request headers captured from the browser (needed by many sites).
#[derive(Serialize, Deserialize, Clone, Debug, Default)]
pub struct ReqHeaders {
    pub referer: Option<String>,
    pub cookie: Option<String>,
    pub user_agent: Option<String>,
}

/// Video-site download handled by yt-dlp. `height` None = best H.264 up to 1080p.
#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct MediaSpec {
    pub height: Option<u32>,
    pub audio: bool,
}

/// One byte range of the file. `end` is inclusive; `u64::MAX` = unknown length.
#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Segment {
    pub start: u64,
    pub end: u64,
    pub done: u64,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Item {
    pub id: u64,
    pub url: String,
    pub filename: String,
    pub dir: String,
    #[serde(default)]
    pub name_locked: bool,
    pub total: Option<u64>,
    #[serde(default)]
    pub resumable: bool,
    pub status: Status,
    #[serde(default)]
    pub segments: Vec<Segment>,
    #[serde(default)]
    pub downloaded: u64,
    #[serde(default)]
    pub speed: u64,
    #[serde(default)]
    pub error: Option<String>,
    #[serde(default)]
    pub added: u64,
    #[serde(default)]
    pub headers: ReqHeaders,
    #[serde(default)]
    pub media: Option<MediaSpec>,
    /// `dir` is final (chosen by the user, or already sorted into a category folder)
    #[serde(default)]
    pub dir_custom: bool,
    /// time spent downloading, milliseconds
    #[serde(default)]
    pub active_ms: u64,
}

/// What the UI sees (no segment list).
#[derive(Serialize, Clone, Debug)]
pub struct View {
    pub id: u64,
    pub url: String,
    pub filename: String,
    pub dir: String,
    pub total: Option<u64>,
    pub resumable: bool,
    pub status: Status,
    pub downloaded: u64,
    pub speed: u64,
    pub error: Option<String>,
    pub added: u64,
    pub media: bool,
    /// seconds spent downloading
    pub elapsed: u64,
}

impl From<&Item> for View {
    fn from(i: &Item) -> Self {
        View {
            id: i.id,
            url: i.url.clone(),
            filename: i.filename.clone(),
            dir: i.dir.clone(),
            total: i.total,
            resumable: i.resumable,
            status: i.status,
            downloaded: i.downloaded,
            speed: i.speed,
            error: i.error.clone(),
            added: i.added,
            media: i.media.is_some(),
            elapsed: i.active_ms / 1000,
        }
    }
}

fn yes() -> bool {
    true
}

pub fn default_categories() -> HashMap<String, String> {
    [
        ("video", "Video"),
        ("music", "Music"),
        ("documents", "Documents"),
        ("programs", "Programs"),
        ("compressed", "Compressed"),
        ("images", "Images"),
        ("other", "Other"),
    ]
    .iter()
    .map(|(k, v)| (k.to_string(), v.to_string()))
    .collect()
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Settings {
    pub dir: String,
    /// Parallel connections per file.
    pub connections: u32,
    /// Downloads running at the same time.
    pub max_active: u32,
    /// Sort finished files into folders by type.
    #[serde(default = "yes")]
    pub categorize: bool,
    /// category key -> folder name
    #[serde(default = "default_categories")]
    pub categories: HashMap<String, String>,
    /// Small floating window with progress while downloading.
    #[serde(default = "yes")]
    pub mini_window: bool,
    /// Start with Windows.
    #[serde(default = "yes")]
    pub autostart: bool,
    #[serde(default)]
    pub version: u32,
}

impl Settings {
    pub fn new(dir: String) -> Self {
        Settings {
            dir,
            connections: 16,
            max_active: 3,
            categorize: true,
            categories: default_categories(),
            mini_window: true,
            autostart: true,
            version: 2,
        }
    }

    pub fn clamped(mut self) -> Self {
        self.connections = self.connections.clamp(1, 32);
        self.max_active = self.max_active.clamp(1, 10);
        for (k, d) in default_categories() {
            let v = self.categories.get(&k).cloned().unwrap_or_default();
            let v: String = v.chars().filter(|c| !"\\/:*?\"<>|".contains(*c)).collect::<String>().trim().to_string();
            self.categories.insert(k, if v.is_empty() { d } else { v });
        }
        self
    }
}

/// Things the app may want to tell the user about (notifications).
#[derive(Clone, Debug)]
pub enum Event {
    Completed { filename: String, dir: String },
    Failed { filename: String, error: String },
}

#[derive(Serialize, Deserialize, Debug)]
pub(crate) struct Persist {
    pub next_id: u64,
    pub settings: Settings,
    pub items: Vec<Item>,
}
