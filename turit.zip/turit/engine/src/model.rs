use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Clone, Copy, Debug, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum Status {
    Queued,
    Downloading,
    Paused,
    Completed,
    Error,
}

/// Extra request headers captured from the browser (needed by many sites).
#[derive(Serialize, Deserialize, Clone, Debug, Default)]
pub struct ReqHeaders {
    pub referer: Option<String>,
    pub cookie: Option<String>,
    pub user_agent: Option<String>,
}

/// Video-site download handled by yt-dlp. `height` None = best H.264 up to 1080p.
#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct MediaSpec {
    pub height: Option<u32>,
    pub audio: bool,
}

/// One byte range of the file. `end` is inclusive; `u64::MAX` = unknown length.
#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Segment {
    pub start: u64,
    pub end: u64,
    pub done: u64,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Item {
    pub id: u64,
    pub url: String,
    pub filename: String,
    pub dir: String,
    #[serde(default)]
    pub name_locked: bool,
    pub total: Option<u64>,
    #[serde(default)]
    pub resumable: bool,
    pub status: Status,
    #[serde(default)]
    pub segments: Vec<Segment>,
    #[serde(default)]
    pub downloaded: u64,
    #[serde(default)]
    pub speed: u64,
    #[serde(default)]
    pub error: Option<String>,
    #[serde(default)]
    pub added: u64,
    #[serde(default)]
    pub headers: ReqHeaders,
    #[serde(default)]
    pub media: Option<MediaSpec>,
}

/// What the UI sees (no segment list).
#[derive(Serialize, Clone, Debug)]
pub struct View {
    pub id: u64,
    pub url: String,
    pub filename: String,
    pub dir: String,
    pub total: Option<u64>,
    pub resumable: bool,
    pub status: Status,
    pub downloaded: u64,
    pub speed: u64,
    pub error: Option<String>,
    pub added: u64,
    pub media: bool,
}

impl From<&Item> for View {
    fn from(i: &Item) -> Self {
        View {
            id: i.id,
            url: i.url.clone(),
            filename: i.filename.clone(),
            dir: i.dir.clone(),
            total: i.total,
            resumable: i.resumable,
            status: i.status,
            downloaded: i.downloaded,
            speed: i.speed,
            error: i.error.clone(),
            added: i.added,
            media: i.media.is_some(),
        }
    }
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Settings {
    pub dir: String,
    /// Parallel connections per file.
    pub connections: u32,
    /// Downloads running at the same time.
    pub max_active: u32,
}

impl Settings {
    pub fn clamped(mut self) -> Self {
        self.connections = self.connections.clamp(1, 32);
        self.max_active = self.max_active.clamp(1, 10);
        self
    }
}

#[derive(Serialize, Deserialize, Debug)]
pub(crate) struct Persist {
    pub next_id: u64,
    pub settings: Settings,
    pub items: Vec<Item>,
}
