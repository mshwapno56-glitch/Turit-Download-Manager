//! Video-site support through yt-dlp (+ ffmpeg for merging video and audio).
//! Qualities are limited to MP4 / H.264 / AAC so that the result plays on phones.

use crate::model::ReqHeaders;
use serde::Serialize;
use serde_json::Value;
use std::path::{Path, PathBuf};
use std::process::Stdio;
use std::time::Duration;
use tokio::process::Command;

#[derive(Serialize, Clone, Debug)]
pub struct MediaOption {
    pub height: Option<u32>,
    pub audio: bool,
    pub size: Option<u64>,
    pub label: String,
}

#[derive(Serialize, Clone, Debug)]
pub struct MediaInfo {
    pub title: String,
    pub duration: Option<f64>,
    pub thumbnail: Option<String>,
    /// true = every listed quality is H.264 (plays on phones)
    pub compat: bool,
    pub options: Vec<MediaOption>,
}

/// Find a helper program (yt-dlp, ffmpeg) in the given folders, else rely on PATH.
pub fn tool_path(dirs: &[PathBuf], name: &str) -> PathBuf {
    let file = if cfg!(windows) { format!("{name}.exe") } else { name.to_string() };
    for d in dirs {
        let p = d.join(&file);
        if p.is_file() {
            return p;
        }
    }
    PathBuf::from(file)
}

pub fn command(program: &Path) -> Command {
    let mut c = Command::new(program);
    #[cfg(windows)]
    {
        c.creation_flags(0x0800_0000); // no console window
    }
    c.kill_on_drop(true).stdin(Stdio::null());
    c
}

pub fn header_args(h: &ReqHeaders) -> Vec<String> {
    let mut v = vec![];
    if let Some(r) = h.referer.as_deref().filter(|s| !s.is_empty()) {
        v.push("--referer".to_string());
        v.push(r.to_string());
    }
    if let Some(u) = h.user_agent.as_deref().filter(|s| !s.is_empty()) {
        v.push("--user-agent".to_string());
        v.push(u.to_string());
    }
    if let Some(c) = h.cookie.as_deref().filter(|s| !s.is_empty()) {
        v.push("--add-header".to_string());
        v.push(format!("Cookie:{c}"));
    }
    v
}

/// yt-dlp format selection: H.264 video + AAC audio merged into MP4.
pub fn format_args(height: Option<u32>, audio: bool) -> Vec<String> {
    if audio {
        return ["-f", "ba[ext=m4a]/ba/b", "-x", "--audio-format", "m4a"].iter().map(|s| s.to_string()).collect();
    }
    let h = height.unwrap_or(1080);
    let f = format!(
        "bv*[height<={h}][vcodec~='^(avc|h264)']+ba[ext=m4a]/b[height<={h}][ext=mp4]/bv*[height<={h}]+ba/b[height<={h}]/b"
    );
    vec!["-f".into(), f, "--merge-output-format".into(), "mp4".into(), "--remux-video".into(), "mp4".into()]
}

fn size_of(f: &Value) -> Option<u64> {
    f["filesize"].as_u64().or_else(|| f["filesize_approx"].as_f64().map(|x| x as u64))
}

fn codec_is(f: &Value, key: &str) -> bool {
    f[key].as_str().map(|c| c != "none").unwrap_or(false)
}

fn is_compat(f: &Value) -> bool {
    let v = f["vcodec"].as_str().unwrap_or("").to_ascii_lowercase();
    v.starts_with("avc") || v.starts_with("h264") || f["ext"].as_str() == Some("mp4")
}

/// Ask yt-dlp which qualities a page offers.
pub async fn probe(ytdlp: &Path, url: &str, h: &ReqHeaders) -> Result<MediaInfo, String> {
    let mut c = command(ytdlp);
    c.args(["-J", "--no-playlist", "--no-warnings", "--encoding", "utf-8"]);
    c.args(header_args(h));
    c.arg(url);
    c.stdout(Stdio::piped()).stderr(Stdio::piped());
    let out = tokio::time::timeout(Duration::from_secs(60), c.output())
        .await
        .map_err(|_| "yt-dlp timed out".to_string())?
        .map_err(|e| format!("yt-dlp not found: {e}"))?;
    if !out.status.success() {
        let err = String::from_utf8_lossy(&out.stderr);
        let line = err.lines().rev().find(|l| !l.trim().is_empty()).unwrap_or("yt-dlp failed");
        return Err(line.trim().to_string());
    }
    let v: Value = serde_json::from_slice(&out.stdout).map_err(|e| format!("bad yt-dlp output: {e}"))?;
    Ok(info_from_json(&v))
}

pub fn info_from_json(v: &Value) -> MediaInfo {
    let fmts: Vec<&Value> = match v["formats"].as_array() {
        Some(a) => a.iter().collect(),
        None => vec![v],
    };
    let videos: Vec<&Value> = fmts
        .iter()
        .copied()
        .filter(|f| codec_is(f, "vcodec") && f["height"].as_u64().is_some())
        .collect();
    let compat_videos: Vec<&Value> = videos.iter().copied().filter(|f| is_compat(f)).collect();
    let compat = !compat_videos.is_empty();
    let pool = if compat { &compat_videos } else { &videos };

    // best audio-only stream (prefer m4a) for size estimates
    let audio_only: Vec<&Value> = fmts
        .iter()
        .copied()
        .filter(|f| codec_is(f, "acodec") && !codec_is(f, "vcodec"))
        .collect();
    let audio_size = audio_only
        .iter()
        .filter(|f| f["ext"].as_str() == Some("m4a"))
        .filter_map(|f| size_of(f))
        .max()
        .or_else(|| audio_only.iter().filter_map(|f| size_of(f)).max());

    let mut heights: Vec<u64> = pool.iter().filter_map(|f| f["height"].as_u64()).collect();
    heights.sort_unstable();
    heights.dedup();
    heights.reverse();

    let mut options = vec![];
    for h in heights {
        let at: Vec<&&Value> = pool.iter().filter(|f| f["height"].as_u64() == Some(h)).collect();
        let vsize = at.iter().filter_map(|f| size_of(f)).max();
        let has_audio = at.iter().any(|f| codec_is(f, "acodec"));
        let size = match (vsize, has_audio) {
            (Some(s), true) => Some(s),
            (Some(s), false) => Some(s + audio_size.unwrap_or(0)),
            (None, _) => None,
        };
        options.push(MediaOption { height: Some(h as u32), audio: false, size, label: format!("{h}p MP4") });
    }
    if !audio_only.is_empty() || options.is_empty() {
        options.push(MediaOption { height: None, audio: true, size: audio_size, label: "Audio M4A".to_string() });
    }
    MediaInfo {
        title: v["title"].as_str().unwrap_or("video").to_string(),
        duration: v["duration"].as_f64(),
        thumbnail: v["thumbnail"].as_str().map(|s| s.to_string()),
        compat,
        options,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn options_prefer_h264() {
        let v: Value = serde_json::json!({
            "title": "T",
            "formats": [
                {"vcodec":"avc1.640028","acodec":"none","height":1080,"ext":"mp4","filesize":100},
                {"vcodec":"vp9","acodec":"none","height":2160,"ext":"webm","filesize":900},
                {"vcodec":"avc1.4d401f","acodec":"none","height":720,"ext":"mp4","filesize":50},
                {"vcodec":"none","acodec":"mp4a.40.2","ext":"m4a","filesize":10}
            ]
        });
        let i = info_from_json(&v);
        assert!(i.compat);
        let labels: Vec<_> = i.options.iter().map(|o| o.label.as_str()).collect();
        assert_eq!(labels, vec!["1080p MP4", "720p MP4", "Audio M4A"]);
        assert_eq!(i.options[0].size, Some(110));
    }

    #[test]
    fn format_string_has_height() {
        let a = format_args(Some(720), false);
        assert!(a[1].contains("height<=720"));
        assert_eq!(format_args(None, true)[0], "-f");
    }
}
