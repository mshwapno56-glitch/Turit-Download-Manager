const API = "http://127.0.0.1:6892";

async function alive() {
  try {
    const r = await fetch(API + "/ping", { cache: "no-store" });
    return r.ok;
  } catch (_) {
    return false;
  }
}

async function cookieHeader(url) {
  try {
    const cs = await chrome.cookies.getAll({ url });
    return cs.map((c) => c.name + "=" + c.value).join("; ");
  } catch (_) {
    return "";
  }
}

async function sendToTurit(url, referer, filename) {
  const body = { url, referer: referer || null, cookie: await cookieHeader(url), userAgent: navigator.userAgent };
  if (filename) body.filename = filename;
  const r = await fetch(API + "/add", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return r.ok;
}

chrome.downloads.onCreated.addListener(async (d) => {
  try {
    const { enabled = true } = await chrome.storage.local.get("enabled");
    if (!enabled) return;
    if (d.byExtensionId === chrome.runtime.id) return; // our own fallback download
    const url = d.finalUrl || d.url;
    if (!/^https?:/i.test(url)) return;
    if (!(await alive())) return; // app not running: let the browser handle it
    await chrome.downloads.cancel(d.id);
    await chrome.downloads.erase({ id: d.id });
    const ok = await sendToTurit(url, d.referrer);
    if (!ok) chrome.downloads.download({ url }); // fall back to the browser
  } catch (_) {}
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "turit-link",
    title: "Turit দিয়ে ডাউনলোড / Download with Turit",
    contexts: ["link", "video", "audio", "image"],
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const url = info.linkUrl || info.srcUrl;
  if (!url || !/^https?:/i.test(url)) return;
  try {
    if (!(await sendToTurit(url, (tab && tab.url) || info.pageUrl))) throw new Error("rejected");
  } catch (_) {
    chrome.downloads.download({ url });
  }
});

// ---- messages from the floating button (content.js) ----
async function post(path, body) {
  const r = await fetch(API + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return await r.json();
}

async function common(msg) {
  return { url: msg.url, referer: msg.referer || null, cookie: await cookieHeader(msg.url), userAgent: navigator.userAgent };
}

async function handleMessage(msg) {
  try {
    if (msg.type === "formats") return await post("/formats", await common(msg));
    if (msg.type === "addMedia") {
      const body = await common(msg);
      body.height = msg.height == null ? null : msg.height;
      body.audio = !!msg.audio;
      body.title = msg.title || null;
      return await post("/add-media", body);
    }
    if (msg.type === "addDirect") return await post("/add", await common(msg));
  } catch (_) {
    return { ok: false, error: "app" };
  }
  return { ok: false, error: "unknown" };
}

chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
  handleMessage(msg).then(respond);
  return true; // async response
});
